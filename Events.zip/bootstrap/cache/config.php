<?php return array (
  'app' => 
  array (
    'name' => 'The Events',
    'env' => 'local',
    'debug' => true,
    'url' => 'http://localhost',
    'asset_url' => NULL,
    'timezone' => 'Africa/Cairo',
    'locale' => 'en',
    'fallback_locale' => 'en',
    'faker_locale' => 'en_US',
    'key' => 'base64:5eF/IT8ZC9i6UQbvaDJIpH3rOJck/x0tA3fPymWEnKI=',
    'cipher' => 'AES-256-CBC',
    'maintenance' => 
    array (
      'driver' => 'file',
    ),
    'available_locales' => 
    array (
      'English' => 'en',
      'Arabic' => 'ar',
    ),
    'providers' => 
    array (
      0 => 'Illuminate\\Auth\\AuthServiceProvider',
      1 => 'Illuminate\\Broadcasting\\BroadcastServiceProvider',
      2 => 'Illuminate\\Bus\\BusServiceProvider',
      3 => 'Illuminate\\Cache\\CacheServiceProvider',
      4 => 'Illuminate\\Foundation\\Providers\\ConsoleSupportServiceProvider',
      5 => 'Illuminate\\Cookie\\CookieServiceProvider',
      6 => 'Illuminate\\Database\\DatabaseServiceProvider',
      7 => 'Illuminate\\Encryption\\EncryptionServiceProvider',
      8 => 'Illuminate\\Filesystem\\FilesystemServiceProvider',
      9 => 'Illuminate\\Foundation\\Providers\\FoundationServiceProvider',
      10 => 'Illuminate\\Hashing\\HashServiceProvider',
      11 => 'Illuminate\\Mail\\MailServiceProvider',
      12 => 'Illuminate\\Notifications\\NotificationServiceProvider',
      13 => 'Illuminate\\Pagination\\PaginationServiceProvider',
      14 => 'Illuminate\\Pipeline\\PipelineServiceProvider',
      15 => 'Illuminate\\Queue\\QueueServiceProvider',
      16 => 'Illuminate\\Redis\\RedisServiceProvider',
      17 => 'Illuminate\\Auth\\Passwords\\PasswordResetServiceProvider',
      18 => 'Illuminate\\Session\\SessionServiceProvider',
      19 => 'Illuminate\\Translation\\TranslationServiceProvider',
      20 => 'Illuminate\\Validation\\ValidationServiceProvider',
      21 => 'Illuminate\\View\\ViewServiceProvider',
      22 => 'Laravel\\Passport\\PassportServiceProvider',
      23 => 'App\\Providers\\AppServiceProvider',
      24 => 'App\\Providers\\AuthServiceProvider',
      25 => 'App\\Providers\\EventServiceProvider',
      26 => 'App\\Providers\\RouteServiceProvider',
      27 => 'App\\Providers\\RepoServiceProvider',
      28 => 'Intervention\\Image\\ImageServiceProvider',
    ),
    'aliases' => 
    array (
      'App' => 'Illuminate\\Support\\Facades\\App',
      'Arr' => 'Illuminate\\Support\\Arr',
      'Artisan' => 'Illuminate\\Support\\Facades\\Artisan',
      'Auth' => 'Illuminate\\Support\\Facades\\Auth',
      'Blade' => 'Illuminate\\Support\\Facades\\Blade',
      'Broadcast' => 'Illuminate\\Support\\Facades\\Broadcast',
      'Bus' => 'Illuminate\\Support\\Facades\\Bus',
      'Cache' => 'Illuminate\\Support\\Facades\\Cache',
      'Config' => 'Illuminate\\Support\\Facades\\Config',
      'Cookie' => 'Illuminate\\Support\\Facades\\Cookie',
      'Crypt' => 'Illuminate\\Support\\Facades\\Crypt',
      'Date' => 'Illuminate\\Support\\Facades\\Date',
      'DB' => 'Illuminate\\Support\\Facades\\DB',
      'Eloquent' => 'Illuminate\\Database\\Eloquent\\Model',
      'Event' => 'Illuminate\\Support\\Facades\\Event',
      'File' => 'Illuminate\\Support\\Facades\\File',
      'Gate' => 'Illuminate\\Support\\Facades\\Gate',
      'Hash' => 'Illuminate\\Support\\Facades\\Hash',
      'Http' => 'Illuminate\\Support\\Facades\\Http',
      'Js' => 'Illuminate\\Support\\Js',
      'Lang' => 'Illuminate\\Support\\Facades\\Lang',
      'Log' => 'Illuminate\\Support\\Facades\\Log',
      'Mail' => 'Illuminate\\Support\\Facades\\Mail',
      'Notification' => 'Illuminate\\Support\\Facades\\Notification',
      'Password' => 'Illuminate\\Support\\Facades\\Password',
      'Queue' => 'Illuminate\\Support\\Facades\\Queue',
      'RateLimiter' => 'Illuminate\\Support\\Facades\\RateLimiter',
      'Redirect' => 'Illuminate\\Support\\Facades\\Redirect',
      'Request' => 'Illuminate\\Support\\Facades\\Request',
      'Response' => 'Illuminate\\Support\\Facades\\Response',
      'Route' => 'Illuminate\\Support\\Facades\\Route',
      'Schema' => 'Illuminate\\Support\\Facades\\Schema',
      'Session' => 'Illuminate\\Support\\Facades\\Session',
      'Storage' => 'Illuminate\\Support\\Facades\\Storage',
      'Str' => 'Illuminate\\Support\\Str',
      'URL' => 'Illuminate\\Support\\Facades\\URL',
      'Validator' => 'Illuminate\\Support\\Facades\\Validator',
      'View' => 'Illuminate\\Support\\Facades\\View',
      'Vite' => 'Illuminate\\Support\\Facades\\Vite',
      'Image' => 'Intervention\\Image\\Facades\\Image',
    ),
  ),
  'auth' => 
  array (
    'defaults' => 
    array (
      'guard' => 'web',
      'passwords' => 'users',
    ),
    'guards' => 
    array (
      'web' => 
      array (
        'driver' => 'session',
        'provider' => 'users',
      ),
      'admin' => 
      array (
        'driver' => 'session',
        'provider' => 'admins',
      ),
      'sanctum' => 
      array (
        'driver' => 'sanctum',
        'provider' => NULL,
      ),
    ),
    'providers' => 
    array (
      'users' => 
      array (
        'driver' => 'eloquent',
        'model' => 'App\\Models\\User',
      ),
      'admins' => 
      array (
        'driver' => 'eloquent',
        'model' => 'App\\Models\\Admin',
      ),
    ),
    'passwords' => 
    array (
      'users' => 
      array (
        'provider' => 'users',
        'table' => 'password_resets',
        'expire' => 60,
        'throttle' => 60,
      ),
      'admins' => 
      array (
        'provider' => 'admins',
        'table' => 'password_resets',
        'expire' => 60,
        'throttle' => 60,
      ),
    ),
    'password_timeout' => 10800,
  ),
  'broadcasting' => 
  array (
    'default' => 'log',
    'connections' => 
    array (
      'pusher' => 
      array (
        'driver' => 'pusher',
        'key' => '',
        'secret' => '',
        'app_id' => '',
        'options' => 
        array (
          'host' => 'api-mt1.pusher.com',
          'port' => '443',
          'scheme' => 'https',
          'encrypted' => true,
          'useTLS' => true,
        ),
        'client_options' => 
        array (
        ),
      ),
      'ably' => 
      array (
        'driver' => 'ably',
        'key' => NULL,
      ),
      'redis' => 
      array (
        'driver' => 'redis',
        'connection' => 'default',
      ),
      'log' => 
      array (
        'driver' => 'log',
      ),
      'null' => 
      array (
        'driver' => 'null',
      ),
    ),
  ),
  'cache' => 
  array (
    'default' => 'file',
    'stores' => 
    array (
      'apc' => 
      array (
        'driver' => 'apc',
      ),
      'array' => 
      array (
        'driver' => 'array',
        'serialize' => false,
      ),
      'database' => 
      array (
        'driver' => 'database',
        'table' => 'cache',
        'connection' => NULL,
        'lock_connection' => NULL,
      ),
      'file' => 
      array (
        'driver' => 'file',
        'path' => 'E:\\Mostafa Gamal\\mostafa\\Events Full Project\\phase1\\events_git\\Events\\storage\\framework/cache/data',
      ),
      'memcached' => 
      array (
        'driver' => 'memcached',
        'persistent_id' => NULL,
        'sasl' => 
        array (
          0 => NULL,
          1 => NULL,
        ),
        'options' => 
        array (
        ),
        'servers' => 
        array (
          0 => 
          array (
            'host' => '127.0.0.1',
            'port' => 11211,
            'weight' => 100,
          ),
        ),
      ),
      'redis' => 
      array (
        'driver' => 'redis',
        'connection' => 'cache',
        'lock_connection' => 'default',
      ),
      'dynamodb' => 
      array (
        'driver' => 'dynamodb',
        'key' => '',
        'secret' => '',
        'region' => 'us-east-1',
        'table' => 'cache',
        'endpoint' => NULL,
      ),
      'octane' => 
      array (
        'driver' => 'octane',
      ),
    ),
    'prefix' => 'the_events_cache_',
  ),
  'cors' => 
  array (
    'paths' => 
    array (
      0 => 'api/*',
      1 => 'sanctum/csrf-cookie',
    ),
    'allowed_methods' => 
    array (
      0 => '*',
    ),
    'allowed_origins' => 
    array (
      0 => '*',
    ),
    'allowed_origins_patterns' => 
    array (
    ),
    'allowed_headers' => 
    array (
      0 => '*',
    ),
    'exposed_headers' => 
    array (
    ),
    'max_age' => 0,
    'supports_credentials' => false,
  ),
  'database' => 
  array (
    'default' => 'mysql',
    'connections' => 
    array (
      'sqlite' => 
      array (
        'driver' => 'sqlite',
        'url' => NULL,
        'database' => 'event_git',
        'prefix' => '',
        'foreign_key_constraints' => true,
      ),
      'mysql' => 
      array (
        'driver' => 'mysql',
        'url' => NULL,
        'host' => '127.0.0.1',
        'port' => '3306',
        'database' => 'event_git',
        'username' => 'root',
        'password' => '',
        'unix_socket' => '',
        'charset' => 'utf8mb4',
        'collation' => 'utf8mb4_unicode_ci',
        'prefix' => '',
        'prefix_indexes' => true,
        'strict' => false,
        'engine' => NULL,
        'options' => 
        array (
        ),
      ),
      'pgsql' => 
      array (
        'driver' => 'pgsql',
        'url' => NULL,
        'host' => '127.0.0.1',
        'port' => '3306',
        'database' => 'event_git',
        'username' => 'root',
        'password' => '',
        'charset' => 'utf8',
        'prefix' => '',
        'prefix_indexes' => true,
        'search_path' => 'public',
        'sslmode' => 'prefer',
      ),
      'sqlsrv' => 
      array (
        'driver' => 'sqlsrv',
        'url' => NULL,
        'host' => '127.0.0.1',
        'port' => '3306',
        'database' => 'event_git',
        'username' => 'root',
        'password' => '',
        'charset' => 'utf8',
        'prefix' => '',
        'prefix_indexes' => true,
      ),
    ),
    'migrations' => 'migrations',
    'redis' => 
    array (
      'client' => 'phpredis',
      'options' => 
      array (
        'cluster' => 'redis',
        'prefix' => 'the_events_database_',
      ),
      'default' => 
      array (
        'url' => NULL,
        'host' => '127.0.0.1',
        'username' => NULL,
        'password' => NULL,
        'port' => '6379',
        'database' => '0',
      ),
      'cache' => 
      array (
        'url' => NULL,
        'host' => '127.0.0.1',
        'username' => NULL,
        'password' => NULL,
        'port' => '6379',
        'database' => '1',
      ),
    ),
  ),
  'filesystems' => 
  array (
    'default' => 'local',
    'disks' => 
    array (
      'local' => 
      array (
        'driver' => 'local',
        'root' => 'E:\\Mostafa Gamal\\mostafa\\Events Full Project\\phase1\\events_git\\Events\\storage\\app',
        'throw' => false,
      ),
      'public' => 
      array (
        'driver' => 'local',
        'root' => 'E:\\Mostafa Gamal\\mostafa\\Events Full Project\\phase1\\events_git\\Events\\storage\\app/public',
        'url' => 'http://localhost/storage',
        'visibility' => 'public',
        'throw' => false,
      ),
      'public_uploads' => 
      array (
        'driver' => 'local',
        'root' => 'E:\\Mostafa Gamal\\mostafa\\Events Full Project\\phase1\\events_git\\Events\\public\\uploads',
        'visibility' => 'public',
      ),
      's3' => 
      array (
        'driver' => 's3',
        'key' => '',
        'secret' => '',
        'region' => 'us-east-1',
        'bucket' => '',
        'url' => NULL,
        'endpoint' => NULL,
        'use_path_style_endpoint' => false,
        'throw' => false,
      ),
    ),
    'links' => 
    array (
      'E:\\Mostafa Gamal\\mostafa\\Events Full Project\\phase1\\events_git\\Events\\public\\storage' => 'E:\\Mostafa Gamal\\mostafa\\Events Full Project\\phase1\\events_git\\Events\\storage\\app/public',
    ),
  ),
  'hashing' => 
  array (
    'driver' => 'bcrypt',
    'bcrypt' => 
    array (
      'rounds' => 10,
    ),
    'argon' => 
    array (
      'memory' => 65536,
      'threads' => 1,
      'time' => 4,
    ),
  ),
  'image' => 
  array (
    'driver' => 'gd',
  ),
  'imageDimensions' => 
  array (
    'app_logo' => 
    array (
      'width' => 200,
      'height' => 200,
    ),
    'app_logo_light' => 
    array (
      'width' => 200,
      'height' => 200,
    ),
    'products' => 
    array (
      'width' => 600,
      'height' => 600,
    ),
    'products_categories' => 
    array (
      'width' => 400,
      'height' => 400,
    ),
    'users' => 
    array (
      'width' => 300,
      'height' => 300,
    ),
    'admins' => 
    array (
      'width' => 300,
      'height' => 300,
    ),
    'blogs' => 
    array (
      'width' => 1200,
      'height' => 800,
    ),
    'pages' => 
    array (
      'width' => 1200,
      'height' => 800,
    ),
  ),
  'laratrust' => 
  array (
    'use_morph_map' => false,
    'checker' => 'default',
    'cache' => 
    array (
      'enabled' => false,
      'expiration_time' => 3600,
    ),
    'user_models' => 
    array (
      'users' => 'App\\Models\\Admin',
    ),
    'models' => 
    array (
      'role' => 'App\\Models\\Role',
      'permission' => 'App\\Models\\Permission',
      'team' => 'App\\Models\\Team',
    ),
    'tables' => 
    array (
      'roles' => 'roles',
      'permissions' => 'permissions',
      'teams' => 'teams',
      'role_user' => 'role_user',
      'permission_user' => 'permission_user',
      'permission_role' => 'permission_role',
    ),
    'foreign_keys' => 
    array (
      'user' => 'user_id',
      'role' => 'role_id',
      'permission' => 'permission_id',
      'team' => 'team_id',
    ),
    'middleware' => 
    array (
      'register' => true,
      'handling' => 'abort',
      'handlers' => 
      array (
        'abort' => 
        array (
          'code' => 403,
          'message' => 'User does not have any of the necessary access rights.',
        ),
        'redirect' => 
        array (
          'url' => '/home',
          'message' => 
          array (
            'key' => 'error',
            'content' => '',
          ),
        ),
      ),
    ),
    'teams' => 
    array (
      'enabled' => false,
      'strict_check' => false,
    ),
    'magic_is_able_to_method_case' => 'kebab_case',
    'permissions_as_gates' => false,
    'panel' => 
    array (
      'register' => false,
      'path' => 'laratrust',
      'go_back_route' => '/',
      'middleware' => 
      array (
        0 => 'web',
      ),
      'assign_permissions_to_user' => true,
      'create_permissions' => true,
      'roles_restrictions' => 
      array (
        'not_removable' => 
        array (
        ),
        'not_editable' => 
        array (
        ),
        'not_deletable' => 
        array (
        ),
      ),
    ),
  ),
  'laratrust_seeder' => 
  array (
    'create_users' => false,
    'truncate_tables' => true,
    'roles_structure' => 
    array (
      'super-admin' => 
      array (
        'users' => 'c,r,u,d',
        'system-admins' => 'c,r,u,d',
        'vendor-admins' => 'c,r,u,d',
        'admin-categories' => 'c,r,u,d',
        'vendors' => 'c,r,u,d',
        'halls' => 'c,r,u,d',
        'halls-categories' => 'c,r,u,d',
        'packages' => 'c,r,u,d',
        'packages-options-categories' => 'c,r,u,d',
        'packages-options' => 'c,r,u,d',
        'packages-available-dates-and-times' => 'c,r,u,d',
        'bookings' => 'c,r,u,d',
        'products-categories' => 'c,r,u,d',
        'products' => 'c,r,u,d',
        'products-reviews' => 'c,r,u,d',
        'orders' => 'c,r,u,d',
        'taxes' => 'c,r,u,d',
        'promo-codes' => 'c,r,u,d',
        'shippings' => 'c,r,u,d',
        'ads-categories' => 'c,r,u,d',
        'ads' => 'c,r,u,d',
        'home-slider' => 'c,r,u,d',
        'countries' => 'c,r,u,d',
        'cities' => 'c,r,u,d',
        'regions' => 'c,r,u,d',
        'contacts' => 'c,r,u,d',
        'pages' => 'c,r,u,d',
        'settings' => 'c,r,u,d',
        'reports' => 'c,r,u,d',
        'notifications' => 'c,r,u,d',
        'area' => 'r',
        'colors' => 'c,r,u,d',
        'sizes' => 'c,r,u,d',
        'shipping' => 'c,r,u,d',
        'digital_cart' => 'c,r,u,d',
        'become_vendor' => 'c,r,u,d',
        'hall_request' => 'c,r,u,d',
        'product_request' => 'c,r,u,d',
        'occasion' => 'c,r,u,d',
        'with-darw' => 'c,r,u,d',
        'my-advertisements' => 'r',
      ),
      'admin' => 
      array (
      ),
      'vendor-admin' => 
      array (
      ),
    ),
    'permissions_map' => 
    array (
      'c' => 'create',
      'r' => 'read',
      'u' => 'update',
      'd' => 'delete',
    ),
  ),
  'laravel-share' => 
  array (
    'services' => 
    array (
      'facebook' => 
      array (
        'uri' => 'https://www.facebook.com/sharer/sharer.php?u=',
      ),
      'twitter' => 
      array (
        'uri' => 'https://twitter.com/intent/tweet',
        'text' => 'Default share text',
      ),
      'linkedin' => 
      array (
        'uri' => 'https://www.linkedin.com/sharing/share-offsite',
        'extra' => 
        array (
          'mini' => 'true',
        ),
      ),
      'whatsapp' => 
      array (
        'uri' => 'https://wa.me/?text=',
        'extra' => 
        array (
          'mini' => 'true',
        ),
      ),
      'pinterest' => 
      array (
        'uri' => 'https://pinterest.com/pin/create/button/?url=',
      ),
      'reddit' => 
      array (
        'uri' => 'https://www.reddit.com/submit',
        'text' => 'Default share text',
      ),
      'telegram' => 
      array (
        'uri' => 'https://telegram.me/share/url',
        'text' => 'Default share text',
      ),
    ),
    'fontAwesomeVersion' => 5,
  ),
  'logging' => 
  array (
    'default' => 'stack',
    'deprecations' => 
    array (
      'channel' => NULL,
      'trace' => false,
    ),
    'channels' => 
    array (
      'stack' => 
      array (
        'driver' => 'stack',
        'channels' => 
        array (
          0 => 'single',
        ),
        'ignore_exceptions' => false,
      ),
      'single' => 
      array (
        'driver' => 'single',
        'path' => 'E:\\Mostafa Gamal\\mostafa\\Events Full Project\\phase1\\events_git\\Events\\storage\\logs/laravel.log',
        'level' => 'debug',
      ),
      'daily' => 
      array (
        'driver' => 'daily',
        'path' => 'E:\\Mostafa Gamal\\mostafa\\Events Full Project\\phase1\\events_git\\Events\\storage\\logs/laravel.log',
        'level' => 'debug',
        'days' => 14,
      ),
      'slack' => 
      array (
        'driver' => 'slack',
        'url' => NULL,
        'username' => 'Laravel Log',
        'emoji' => ':boom:',
        'level' => 'debug',
      ),
      'papertrail' => 
      array (
        'driver' => 'monolog',
        'level' => 'debug',
        'handler' => 'Monolog\\Handler\\SyslogUdpHandler',
        'handler_with' => 
        array (
          'host' => NULL,
          'port' => NULL,
          'connectionString' => 'tls://:',
        ),
      ),
      'stderr' => 
      array (
        'driver' => 'monolog',
        'level' => 'debug',
        'handler' => 'Monolog\\Handler\\StreamHandler',
        'formatter' => NULL,
        'with' => 
        array (
          'stream' => 'php://stderr',
        ),
      ),
      'syslog' => 
      array (
        'driver' => 'syslog',
        'level' => 'debug',
      ),
      'errorlog' => 
      array (
        'driver' => 'errorlog',
        'level' => 'debug',
      ),
      'null' => 
      array (
        'driver' => 'monolog',
        'handler' => 'Monolog\\Handler\\NullHandler',
      ),
      'emergency' => 
      array (
        'path' => 'E:\\Mostafa Gamal\\mostafa\\Events Full Project\\phase1\\events_git\\Events\\storage\\logs/laravel.log',
      ),
    ),
  ),
  'mail' => 
  array (
    'default' => 'smtp',
    'mailers' => 
    array (
      'smtp' => 
      array (
        'transport' => 'smtp',
        'host' => 'mailhog',
        'port' => '1025',
        'encryption' => NULL,
        'username' => NULL,
        'password' => NULL,
        'timeout' => NULL,
        'local_domain' => NULL,
      ),
      'ses' => 
      array (
        'transport' => 'ses',
      ),
      'mailgun' => 
      array (
        'transport' => 'mailgun',
      ),
      'postmark' => 
      array (
        'transport' => 'postmark',
      ),
      'sendmail' => 
      array (
        'transport' => 'sendmail',
        'path' => '/usr/sbin/sendmail -bs -i',
      ),
      'log' => 
      array (
        'transport' => 'log',
        'channel' => NULL,
      ),
      'array' => 
      array (
        'transport' => 'array',
      ),
      'failover' => 
      array (
        'transport' => 'failover',
        'mailers' => 
        array (
          0 => 'smtp',
          1 => 'log',
        ),
      ),
    ),
    'from' => 
    array (
      'address' => 'hello@example.com',
      'name' => 'The Events',
    ),
    'markdown' => 
    array (
      'theme' => 'default',
      'paths' => 
      array (
        0 => 'E:\\Mostafa Gamal\\mostafa\\Events Full Project\\phase1\\events_git\\Events\\resources\\views/vendor/mail',
      ),
    ),
  ),
  'queue' => 
  array (
    'default' => 'sync',
    'connections' => 
    array (
      'sync' => 
      array (
        'driver' => 'sync',
      ),
      'database' => 
      array (
        'driver' => 'database',
        'table' => 'jobs',
        'queue' => 'default',
        'retry_after' => 90,
        'after_commit' => false,
      ),
      'beanstalkd' => 
      array (
        'driver' => 'beanstalkd',
        'host' => 'localhost',
        'queue' => 'default',
        'retry_after' => 90,
        'block_for' => 0,
        'after_commit' => false,
      ),
      'sqs' => 
      array (
        'driver' => 'sqs',
        'key' => '',
        'secret' => '',
        'prefix' => 'https://sqs.us-east-1.amazonaws.com/your-account-id',
        'queue' => 'default',
        'suffix' => NULL,
        'region' => 'us-east-1',
        'after_commit' => false,
      ),
      'redis' => 
      array (
        'driver' => 'redis',
        'connection' => 'default',
        'queue' => 'default',
        'retry_after' => 90,
        'block_for' => NULL,
        'after_commit' => false,
      ),
    ),
    'failed' => 
    array (
      'driver' => 'database-uuids',
      'database' => 'mysql',
      'table' => 'failed_jobs',
    ),
  ),
  'response' => 
  array (
    'email_exist' => 
    array (
      'ar' => 'البريد الإلكتروني موجود من قبل',
      'en' => 'Email already exists',
    ),
    'phone_exist' => 
    array (
      'ar' => 'الهاتف موجود من قبل',
      'en' => 'Phone already exists',
    ),
    'registered' => 
    array (
      'ar' => 'تم التسجيل بنجاح, برجاء تم ارسال بريد الكتروني يحتوي علي رقم التفعيل من فضلك قم بتفعيل الحساب',
      'en' => 'The registration was successful. Please, an e-mail has been sent containing the activation number. Please activate the account',
    ),
    'activated' => 
    array (
      'ar' => 'تم التفعيل بنجاح',
      'en' => 'Activated Successfully',
    ),
    'invalid_data' => 
    array (
      'ar' => 'بيانات خاطئة',
      'en' => 'Invalid Data',
    ),
    'user_not_found' => 
    array (
      'ar' => 'مستخدم غير موجود',
      'en' => 'User does\'nt exist',
    ),
    'user_not_verified' => 
    array (
      'ar' => 'مستخدم غير مفعل',
      'en' => 'User not active',
    ),
    'invalid_email' => 
    array (
      'ar' => 'خطأ في البريد الإلكتروني',
      'en' => 'Invalid Email',
    ),
    'invalid_password' => 
    array (
      'ar' => 'خطأ في كلمة المرور',
      'en' => 'Invalid Password',
    ),
    'invalid_oldpassword' => 
    array (
      'ar' => 'خطأ في كلمة المرور القديمه',
      'en' => 'Invalid Old Password',
    ),
    'password_changed' => 
    array (
      'ar' => 'تم إعادة تعيين كلمة المرور بنجاح',
      'en' => 'Password has been reset successfully',
    ),
    'invalid_code' => 
    array (
      'ar' => 'كود غير صحيح',
      'en' => 'Invalid Code',
    ),
    'logged_in' => 
    array (
      'ar' => 'تم الدخول',
      'en' => 'Logged In',
    ),
    'code_sent' => 
    array (
      'ar' => 'تم إرسال الكود',
      'en' => 'Code Sent Successfully',
    ),
    'user_profile' => 
    array (
      'ar' => 'البيانات الشخصيه',
      'en' => 'profile data',
    ),
    'updated' => 
    array (
      'ar' => 'تم التعديل بنجاح',
      'en' => 'Updated Successfully',
    ),
    'logout' => 
    array (
      'en' => 'logout',
      'ar' => 'تم تسجيل الخروج',
    ),
    'Session_Expired' => 
    array (
      'en' => 'Session Expired',
      'ar' => 'تم انتهاء رمز الدخول',
    ),
    'method' => 
    array (
      'en' => 'method not found',
      'ar' => 'المثود غير موجودة',
    ),
    'url' => 
    array (
      'en' => 'url not found',
      'ar' => 'الرابط غير موجود',
    ),
    'home' => 
    array (
      'en' => 'home',
      'ar' => 'الرئيسية',
    ),
    'suggestion_sent' => 
    array (
      'ar' => 'تم الارسال بنجاح',
      'en' => 'Sent Successfully',
    ),
    'terms_cond' => 
    array (
      'ar' => 'الشروط و الاحكام',
      'en' => 'terms and conditions',
    ),
    'order_sent' => 
    array (
      'ar' => 'تم ارسال الطلب',
      'en' => 'Order Sent',
    ),
    'all_orders' => 
    array (
      'ar' => 'كل الطلبات',
      'en' => 'All Orders',
    ),
    'oneorder' => 
    array (
      'ar' => 'بيانات طلب واحد',
      'en' => 'One Order',
    ),
    'order_not_found' => 
    array (
      'en' => 'order not found',
      'ar' => 'الطلب غير موجود',
    ),
    'all_contracts' => 
    array (
      'ar' => 'كل العقود',
      'en' => 'All Contracts',
    ),
    'onecontract' => 
    array (
      'ar' => 'بيانات عقد واحد',
      'en' => 'One Contract',
    ),
    'contract_not_found' => 
    array (
      'ar' => 'لا يوجد لديك عقود',
      'en' => 'you don\'nt have contracts yet',
    ),
    'update_contract' => 
    array (
      'ar' => 'تم كتابة الاجراء المطلوب علي العقد',
      'en' => 'The required procedure was written on the contract',
    ),
    'all_notifications' => 
    array (
      'ar' => 'كل الاشعارات',
      'en' => 'all notifications ',
    ),
    'verification_code_first' => 
    array (
      'en' => 'verify code first before update',
      'ar' => 'قم بتفعيل الكود قبل تعديل العقد',
    ),
    'user_not_activated' => 
    array (
      'en' => 'user account not activated',
      'ar' => 'حساب المستخدم غير نشط',
    ),
    'details' => 
    array (
      'en' => 'details',
      'ar' => 'تفاصيل',
    ),
    'code_not_found' => 
    array (
      'en' => 'code not found',
      'ar' => 'الكود غر موجود',
    ),
    'skip' => 
    array (
      'en' => 'skip',
      'ar' => 'سكيب',
    ),
    'link' => 
    array (
      'en' => 'link',
      'ar' => 'اللينك',
    ),
    'all_nationalities' => 
    array (
      'en' => 'all nationalities',
      'ar' => 'كل الجنسيات',
    ),
    'all_brands' => 
    array (
      'en' => 'all brands',
      'ar' => 'كل البراندات',
    ),
    'all_units' => 
    array (
      'en' => 'all units',
      'ar' => 'كل الوحدات',
    ),
    'all_locations' => 
    array (
      'en' => 'all locations',
      'ar' => 'كل المناطق',
    ),
    'slider_not_found' => 
    array (
      'en' => 'slider not found',
      'ar' => 'لا يوجد سليدر',
    ),
    'slider' => 
    array (
      'en' => 'slider',
      'ar' => 'سليدر',
    ),
    'all_works' => 
    array (
      'en' => 'all works',
      'ar' => 'كل الاعمال',
    ),
    'code_expired' => 
    array (
      'en' => 'code expired',
      'ar' => 'تم انتهاء الكود',
    ),
    'splash' => 
    array (
      'en' => 'splash',
      'ar' => 'سبلاش',
    ),
    'create_contract' => 
    array (
      'en' => 'Your request has been sent and is being approved by the administration',
      'ar' => 'تم ارسال طلبكم و جاري المراجعة من الادارة',
    ),
    'all_types' => 
    array (
      'en' => 'all types',
      'ar' => 'كل الانواع',
    ),
    'review' => 
    array (
      'en' => 'You have an application under review',
      'ar' => 'لديك طلب قيد المراجعة',
    ),
    'please_create_contract' => 
    array (
      'en' => 'Please create a contract to be able to log in',
      'ar' => 'من فضلك قم بانشاء عقد لكي تتمكن من تسجيل الدخول',
    ),
    'expired_please_create_contract' => 
    array (
      'en' => 'there is and expired contract please create new contract',
      'ar' => 'هناك عقد انتهت صلاحيته من فضلك قم بانشاء عقد جديد',
    ),
    'create_contract_not_sned_email' => 
    array (
      'en' => 'contract created but can not send email',
      'ar' => 'تم انشاء عقد ولكن لا يمكن ارسال بريد الكتروني لهذا الايميل',
    ),
    'notification_updated' => 
    array (
      'en' => 'notification deleted',
      'ar' => 'تم حذف الاشعار',
    ),
    'notification_not_found' => 
    array (
      'en' => 'notification not found',
      'ar' => 'الاشعار غير موجود',
    ),
    'order_updated' => 
    array (
      'en' => 'order deleted',
      'ar' => 'تم حذف الطلب',
    ),
    'cities' => 
    array (
      'en' => 'cities',
      'ar' => 'مدن',
    ),
    'no_data' => 
    array (
      'en' => 'no data',
      'ar' => 'لا توجد بيانات',
    ),
    'about' => 
    array (
      'en' => 'about_us',
      'ar' => 'عننا',
    ),
    'regions' => 
    array (
      'en' => 'regions',
      'ar' => 'مناطق',
    ),
    'city_not_found' => 
    array (
      'en' => 'city not found',
      'ar' => 'المدينة غير موجودة',
    ),
    'faqs' => 
    array (
      'en' => 'faqs',
      'ar' => 'اسئلة و اجابات',
    ),
    'colors' => 
    array (
      'en' => 'colors',
      'ar' => 'الالوان',
    ),
    'brands' => 
    array (
      'en' => 'brands',
      'ar' => 'براندات',
    ),
    'main_categories' => 
    array (
      'en' => 'categories',
      'ar' => 'الاقسام',
    ),
    'events-categories' => 
    array (
      'en' => 'events categories',
      'ar' => 'اقسام الاحداث',
    ),
    'event-halls' => 
    array (
      'en' => 'event halls',
      'ar' => 'احداث الصالات',
    ),
    'latest_wedings_halls' => 
    array (
      'en' => 'latest wedings halls',
      'ar' => 'اخر قاعات الافراح',
    ),
    'latest_birthdays_halls' => 
    array (
      'en' => 'latest birthdays halls',
      'ar' => 'اخر قاعات اعياد الميلاد',
    ),
    'latest_engagements_halls' => 
    array (
      'en' => 'latest engagements halls',
      'ar' => 'اخر قاعات الخطوبات',
    ),
    'latest_conferences_halls' => 
    array (
      'en' => 'latest conferences halls',
      'ar' => 'اخر قاعات المؤتمرات',
    ),
    'all_products' => 
    array (
      'en' => 'all products',
      'ar' => 'كل المنتجات',
    ),
    'fave_list' => 
    array (
      'en' => 'fave list',
      'ar' => 'قائمة المفضلة',
    ),
    'fave_deleted' => 
    array (
      'en' => 'fave deleted',
      'ar' => 'حذف المفضلة',
    ),
    'fave_done' => 
    array (
      'en' => 'fave done',
      'ar' => 'تم اضافة الي المفضلة',
    ),
    'brand_products' => 
    array (
      'en' => 'brand products',
      'ar' => 'براندات المنتجات',
    ),
    'category_products' => 
    array (
      'en' => 'category products',
      'ar' => 'قسم المنتجات',
    ),
    'product_details' => 
    array (
      'en' => 'product_details',
      'ar' => 'تفاصيل المنتج',
    ),
    'hall_details' => 
    array (
      'en' => 'hall details',
      'ar' => 'تفاصيل القاعة',
    ),
    'package_details' => 
    array (
      'en' => 'package details',
      'ar' => 'تفاصيل الباقة',
    ),
    'all_queries' => 
    array (
      'en' => 'all queries',
      'ar' => 'كل الاستفسارات',
    ),
    'query_sent' => 
    array (
      'en' => 'query sent',
      'ar' => 'تم ارسال استفسارك',
    ),
  ),
  'sanctum' => 
  array (
    'stateful' => 
    array (
      0 => 'localhost',
      1 => 'localhost:3000',
      2 => '127.0.0.1',
      3 => '127.0.0.1:8000',
      4 => '::1',
      5 => 'localhost',
    ),
    'guard' => 
    array (
      0 => 'web',
    ),
    'expiration' => NULL,
    'middleware' => 
    array (
      'verify_csrf_token' => 'App\\Http\\Middleware\\VerifyCsrfToken',
      'encrypt_cookies' => 'App\\Http\\Middleware\\EncryptCookies',
    ),
  ),
  'services' => 
  array (
    'mailgun' => 
    array (
      'domain' => NULL,
      'secret' => NULL,
      'endpoint' => 'api.mailgun.net',
      'scheme' => 'https',
    ),
    'postmark' => 
    array (
      'token' => NULL,
    ),
    'ses' => 
    array (
      'key' => '',
      'secret' => '',
      'region' => 'us-east-1',
    ),
  ),
  'session' => 
  array (
    'driver' => 'file',
    'lifetime' => '120',
    'expire_on_close' => false,
    'encrypt' => false,
    'files' => 'E:\\Mostafa Gamal\\mostafa\\Events Full Project\\phase1\\events_git\\Events\\storage\\framework/sessions',
    'connection' => NULL,
    'table' => 'sessions',
    'store' => NULL,
    'lottery' => 
    array (
      0 => 2,
      1 => 100,
    ),
    'cookie' => 'the_events_session',
    'path' => '/',
    'domain' => NULL,
    'secure' => NULL,
    'http_only' => true,
    'same_site' => 'lax',
  ),
  'sluggable' => 
  array (
    'source' => NULL,
    'maxLength' => NULL,
    'maxLengthKeepWords' => true,
    'method' => 
    array (
      0 => 'App\\Helper\\MySlugHelper',
      1 => 'slug',
    ),
    'separator' => '-',
    'unique' => true,
    'uniqueSuffix' => NULL,
    'firstUniqueSuffix' => 2,
    'includeTrashed' => false,
    'reserved' => NULL,
    'onUpdate' => true,
    'slugEngineOptions' => 
    array (
    ),
  ),
  'view' => 
  array (
    'paths' => 
    array (
      0 => 'E:\\Mostafa Gamal\\mostafa\\Events Full Project\\phase1\\events_git\\Events\\resources\\views',
    ),
    'compiled' => 'E:\\Mostafa Gamal\\mostafa\\Events Full Project\\phase1\\events_git\\Events\\storage\\framework\\views',
  ),
  'passport' => 
  array (
    'guard' => 'web',
    'private_key' => NULL,
    'public_key' => NULL,
    'client_uuids' => false,
    'personal_access_client' => 
    array (
      'id' => NULL,
      'secret' => NULL,
    ),
  ),
  'flare' => 
  array (
    'key' => NULL,
    'flare_middleware' => 
    array (
      0 => 'Spatie\\FlareClient\\FlareMiddleware\\RemoveRequestIp',
      1 => 'Spatie\\FlareClient\\FlareMiddleware\\AddGitInformation',
      2 => 'Spatie\\LaravelIgnition\\FlareMiddleware\\AddNotifierName',
      3 => 'Spatie\\LaravelIgnition\\FlareMiddleware\\AddEnvironmentInformation',
      4 => 'Spatie\\LaravelIgnition\\FlareMiddleware\\AddExceptionInformation',
      5 => 'Spatie\\LaravelIgnition\\FlareMiddleware\\AddDumps',
      'Spatie\\LaravelIgnition\\FlareMiddleware\\AddLogs' => 
      array (
        'maximum_number_of_collected_logs' => 200,
      ),
      'Spatie\\LaravelIgnition\\FlareMiddleware\\AddQueries' => 
      array (
        'maximum_number_of_collected_queries' => 200,
        'report_query_bindings' => true,
      ),
      'Spatie\\LaravelIgnition\\FlareMiddleware\\AddJobs' => 
      array (
        'max_chained_job_reporting_depth' => 5,
      ),
      'Spatie\\FlareClient\\FlareMiddleware\\CensorRequestBodyFields' => 
      array (
        'censor_fields' => 
        array (
          0 => 'password',
          1 => 'password_confirmation',
        ),
      ),
      'Spatie\\FlareClient\\FlareMiddleware\\CensorRequestHeaders' => 
      array (
        'headers' => 
        array (
          0 => 'API-KEY',
        ),
      ),
    ),
    'send_logs_as_events' => true,
  ),
  'ignition' => 
  array (
    'editor' => 'phpstorm',
    'theme' => 'auto',
    'enable_share_button' => true,
    'register_commands' => false,
    'solution_providers' => 
    array (
      0 => 'Spatie\\Ignition\\Solutions\\SolutionProviders\\BadMethodCallSolutionProvider',
      1 => 'Spatie\\Ignition\\Solutions\\SolutionProviders\\MergeConflictSolutionProvider',
      2 => 'Spatie\\Ignition\\Solutions\\SolutionProviders\\UndefinedPropertySolutionProvider',
      3 => 'Spatie\\LaravelIgnition\\Solutions\\SolutionProviders\\IncorrectValetDbCredentialsSolutionProvider',
      4 => 'Spatie\\LaravelIgnition\\Solutions\\SolutionProviders\\MissingAppKeySolutionProvider',
      5 => 'Spatie\\LaravelIgnition\\Solutions\\SolutionProviders\\DefaultDbNameSolutionProvider',
      6 => 'Spatie\\LaravelIgnition\\Solutions\\SolutionProviders\\TableNotFoundSolutionProvider',
      7 => 'Spatie\\LaravelIgnition\\Solutions\\SolutionProviders\\MissingImportSolutionProvider',
      8 => 'Spatie\\LaravelIgnition\\Solutions\\SolutionProviders\\InvalidRouteActionSolutionProvider',
      9 => 'Spatie\\LaravelIgnition\\Solutions\\SolutionProviders\\ViewNotFoundSolutionProvider',
      10 => 'Spatie\\LaravelIgnition\\Solutions\\SolutionProviders\\RunningLaravelDuskInProductionProvider',
      11 => 'Spatie\\LaravelIgnition\\Solutions\\SolutionProviders\\MissingColumnSolutionProvider',
      12 => 'Spatie\\LaravelIgnition\\Solutions\\SolutionProviders\\UnknownValidationSolutionProvider',
      13 => 'Spatie\\LaravelIgnition\\Solutions\\SolutionProviders\\MissingMixManifestSolutionProvider',
      14 => 'Spatie\\LaravelIgnition\\Solutions\\SolutionProviders\\MissingViteManifestSolutionProvider',
      15 => 'Spatie\\LaravelIgnition\\Solutions\\SolutionProviders\\MissingLivewireComponentSolutionProvider',
      16 => 'Spatie\\LaravelIgnition\\Solutions\\SolutionProviders\\UndefinedViewVariableSolutionProvider',
      17 => 'Spatie\\LaravelIgnition\\Solutions\\SolutionProviders\\GenericLaravelExceptionSolutionProvider',
    ),
    'ignored_solution_providers' => 
    array (
    ),
    'enable_runnable_solutions' => NULL,
    'remote_sites_path' => 'E:\\Mostafa Gamal\\mostafa\\Events Full Project\\phase1\\events_git\\Events',
    'local_sites_path' => '',
    'housekeeping_endpoint_prefix' => '_ignition',
    'settings_file_path' => '',
    'recorders' => 
    array (
      0 => 'Spatie\\LaravelIgnition\\Recorders\\DumpRecorder\\DumpRecorder',
      1 => 'Spatie\\LaravelIgnition\\Recorders\\JobRecorder\\JobRecorder',
      2 => 'Spatie\\LaravelIgnition\\Recorders\\LogRecorder\\LogRecorder',
      3 => 'Spatie\\LaravelIgnition\\Recorders\\QueryRecorder\\QueryRecorder',
    ),
  ),
  'tinker' => 
  array (
    'commands' => 
    array (
    ),
    'alias' => 
    array (
    ),
    'dont_alias' => 
    array (
      0 => 'App\\Nova',
    ),
  ),
);
