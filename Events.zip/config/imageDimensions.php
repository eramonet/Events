<?php

return [



    'app_logo' => [
        'width' => 200,
        'height' => 200,
    ],


    'app_logo_light' => [
        'width' => 200,
        'height' => 200,
    ],

    'products' => [
        'width' => 600,
        'height' => 600,
    ],

    'products_categories' => [
        'width' => 400,
        'height' => 400,
    ],

    'users' => [
        'width' => 300,
        'height' => 300,
    ],
    'admins' => [
        'width' => 300,
        'height' => 300,
    ],

    'blogs' => [
        'width' => 1200,
        'height' => 800,
    ],

    'pages' => [
        'width' => 1200,
        'height' => 800,
    ],



];
