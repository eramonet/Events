@extends('layouts.admin.master')

@section('content')


    <div class="py-4">

        <div class="d-flex justify-content-between w-100 flex-wrap">
            <div class="mb-3 mb-lg-0">
                <h1 class="h4"> <i class="fa fa-house"></i> {{ config('app.name') }} Admin Dashboard </h1>

            </div>

        </div>
    </div>

    <div class="row dashboard-home-top">


        @php
            $colores = collect(['primary', 'secondary', 'success', 'danger', 'warning', 'info', 'light', 'tertiary']);
            $useradmin = App\Models\Admin::where('id', Auth::guard('admin')->id())->first();
            $vendor = App\Models\Vendor::where('id', $useradmin->vendor_id)->first();
        @endphp
        @if ($useradmin->hasRole('super-admin') || $useradmin->hasRole('admin'))
            <div class="col-12 col-sm-6 col-xl-3 mb-4">
                <div class="card border-0 shadow">
                    <div class="card-body">
                        <div class="row d-block d-xl-flex align-items-center">
                            <div
                                class="col-12 col-xl-5 text-xl-center mb-3 mb-xl-0 d-flex align-items-center justify-content-xl-center">
                                <div class="icon-shape icon-shape-{{ $colores->random() }} rounded me-4 me-sm-0">

                                    <i class="fas fa-users icon"></i>
                                </div>
                                <div class="d-sm-none">
                                    <h2 class="h5">Users</h2>

                                    <div class="fw-extrabold mb-1"> <a href="#">{{ $usersCount }}</a></div>
                                </div>
                            </div>
                            <div class="col-12 col-xl-7 px-xl-0">
                                <div class="d-none d-sm-block">
                                    <h2 class="h6 text-gray-400 mb-0">Users</h2>
                                    <a href="{{ route('admin.users.index') }}">
                                        <div class="fw-extrabold mb-1">{{ $usersCount }}</div>
                                    </a>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>
            </div>


            <div class="col-12 col-sm-6 col-xl-3 mb-4">
                <div class="card border-0 shadow">
                    <div class="card-body">
                        <div class="row d-block d-xl-flex align-items-center">
                            <div
                                class="col-12 col-xl-5 text-xl-center mb-3 mb-xl-0 d-flex align-items-center justify-content-xl-center">
                                <div class="icon-shape icon-shape-{{ $colores->random() }} rounded me-4 me-sm-0">

                                    <i class="fas fa-users-cog icon"></i>
                                </div>
                                <div class="d-sm-none">
                                    <h2 class="h5">System Admins</h2>
                                    <div class="fw-extrabold mb-1">{{ $adminsCount }}</div>
                                </div>
                            </div>
                            <div class="col-12 col-xl-7 px-xl-0">
                                <div class="d-none d-sm-block">
                                    <h2 class="h6 text-gray-400 mb-0">System Admins</h2>
                                    <a href="{{ route('admin.system-admins.index') }}">
                                        <div class="fw-extrabold mb-2">{{ $adminsCount }}</div>
                                    </a>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>
            </div>


            <div class="col-12 col-sm-6 col-xl-3 mb-4">
                <div class="card border-0 shadow">
                    <div class="card-body">
                        <div class="row d-block d-xl-flex align-items-center">
                            <div
                                class="col-12 col-xl-5 text-xl-center mb-3 mb-xl-0 d-flex align-items-center justify-content-xl-center">
                                <div class="icon-shape icon-shape-{{ $colores->random() }} rounded me-4 me-sm-0">

                                    <i class="fas fa-ad"></i>
                                </div>
                                <div class="d-sm-none">
                                    <h2 class="h5">Ads</h2>
                                    <div class="fw-extrabold mb-1">{{ $adsCount }}</div>
                                </div>
                            </div>
                            <div class="col-12 col-xl-7 px-xl-0">
                                <div class="d-none d-sm-block">
                                    <h2 class="h6 text-gray-400 mb-0">Ads</h2>
                                    {{-- <a href="{{route("admin.ads.index")}}"> --}}
                                    <div class="fw-extrabold mb-2">{{ $adsCount }}</div>
                                    {{-- </a> --}}
                                </div>

                            </div>
                        </div>
                    </div>
                </div>
            </div>


            <div class="col-12 col-sm-6 col-xl-3 mb-4">
                <div class="card border-0 shadow">
                    <div class="card-body">
                        <div class="row d-block d-xl-flex align-items-center">
                            <div
                                class="col-12 col-xl-5 text-xl-center mb-3 mb-xl-0 d-flex align-items-center justify-content-xl-center">
                                <div class="icon-shape icon-shape-{{ $colores->random() }} rounded me-4 me-sm-0">

                                    <i class="fas fa-briefcase icon"></i>
                                </div>
                                <div class="d-sm-none">
                                    <h2 class="h5">Vendors </h2>
                                    <div class="fw-extrabold mb-1">{{ $vendors }}</div>
                                </div>
                            </div>
                            <div class="col-12 col-xl-7 px-xl-0">
                                <div class="d-none d-sm-block">
                                    <h2 class="h6 text-gray-400 mb-0">Vendors </h2>
                                    <a href="{{ route('admin.vendor-admins.index') }}">
                                        <div class="fw-extrabold mb-2">{{ $vendors }}</div>
                                    </a>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>
            </div>


            <div class="col-12 col-sm-6 col-xl-3 mb-4">
                <div class="card border-0 shadow">
                    <div class="card-body">
                        <div class="row d-block d-xl-flex align-items-center">
                            <div
                                class="col-12 col-xl-5 text-xl-center mb-3 mb-xl-0 d-flex align-items-center justify-content-xl-center">
                                <div class="icon-shape icon-shape-{{ $colores->random() }} rounded me-4 me-sm-0">

                                    <i class="fa-solid fa-bars-staggered icon"></i>
                                </div>
                                <div class="d-sm-none">
                                    <h2 class="h5">Halls Categories</h2>
                                    <div class="fw-extrabold mb-1">{{ $hallCategories }}</div>
                                </div>
                            </div>
                            <div class="col-12 col-xl-7 px-xl-0">
                                <div class="d-none d-sm-block">
                                    <h2 class="h6 text-gray-400 mb-0">Halls Categories</h2>
                                    <a href="{{ route('admin.halls-categories.index') }}">
                                        <div class="fw-extrabold mb-2">{{ $hallCategories }}</div>
                                    </a>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>
            </div>


            <div class="col-12 col-sm-6 col-xl-3 mb-4">
                <div class="card border-0 shadow">
                    <div class="card-body">
                        <div class="row d-block d-xl-flex align-items-center">
                            <div
                                class="col-12 col-xl-5 text-xl-center mb-3 mb-xl-0 d-flex align-items-center justify-content-xl-center">
                                <div class="icon-shape icon-shape-{{ $colores->random() }} rounded me-4 me-sm-0">

                                    <i class="fa-solid fa-wand-sparkles icon"></i>
                                </div>
                                <div class="d-sm-none">
                                    <h2 class="h5">Halls</h2>
                                    <div class="fw-extrabold mb-1">{{ $halls }}</div>
                                </div>
                            </div>
                            <div class="col-12 col-xl-7 px-xl-0">
                                <div class="d-none d-sm-block">
                                    <h2 class="h6 text-gray-400 mb-0">Halls</h2>
                                    <a href="{{ route('admin.halls.index') }}">
                                        <div class="fw-extrabold mb-2">{{ $halls }}</div>
                                    </a>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>
            </div>


            <div class="col-12 col-sm-6 col-xl-3 mb-4">
                <div class="card border-0 shadow">
                    <div class="card-body">
                        <div class="row d-block d-xl-flex align-items-center">
                            <div
                                class="col-12 col-xl-5 text-xl-center mb-3 mb-xl-0 d-flex align-items-center justify-content-xl-center">
                                <div class="icon-shape icon-shape-{{ $colores->random() }} rounded me-4 me-sm-0">

                                    <i class="fa-solid fa-money-bills icon"></i>
                                </div>
                                <div class="d-sm-none">
                                    <h2 class="h5">Total Taxes</h2>
                                    <div class="fw-extrabold mb-1">{{ $taxes }}</div>
                                </div>
                            </div>
                            <div class="col-12 col-xl-7 px-xl-0">
                                <div class="d-none d-sm-block">
                                    <h2 class="h6 text-gray-400 mb-0">Total Taxes</h2>
                                    <a href="{{ route('admin.taxes.index') }}">
                                        <div class="fw-extrabold mb-2">{{ $taxes }}</div>
                                    </a>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>
            </div>


            <div class="col-12 col-sm-6 col-xl-3 mb-4">
                <div class="card border-0 shadow">
                    <div class="card-body">
                        <div class="row d-block d-xl-flex align-items-center">
                            <div
                                class="col-12 col-xl-5 text-xl-center mb-3 mb-xl-0 d-flex align-items-center justify-content-xl-center">
                                <div class="icon-shape icon-shape-{{ $colores->random() }} rounded me-4 me-sm-0">

                                    <i class="fa-solid fa-truck-fast icon"></i>
                                </div>
                                <div class="d-sm-none">
                                    <h2 class="h5">Total Shippings Fees</h2>
                                    <div class="fw-extrabold mb-1">{{ $shippings }}</div>
                                </div>
                            </div>
                            <div class="col-12 col-xl-7 px-xl-0">
                                <div class="d-none d-sm-block">
                                    <h2 class="h6 text-gray-400 mb-0"> Total Shippings Fees</h2>
                                    <a href="{{ route('admin.shippings.index') }}">
                                        <div class="fw-extrabold mb-2">{{ $shippings }}</div>
                                    </a>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-12 col-sm-6 col-xl-3 mb-4">
                <div class="card border-0 shadow">
                    <div class="card-body">
                        <div class="row d-block d-xl-flex align-items-center">
                            <div
                                class="col-12 col-xl-5 text-xl-center mb-3 mb-xl-0 d-flex align-items-center justify-content-xl-center">
                                <div class="icon-shape icon-shape-{{ $colores->random() }} rounded me-4 me-sm-0">

                                    <i class="fas fa-shopping-cart icon"></i>
                                </div>
                                <div class="d-sm-none">
                                    <h2 class="h5"> Total Products</h2>
                                    <div class="fw-extrabold mb-1">{{ $products }}</div>
                                </div>
                            </div>
                            <div class="col-12 col-xl-7 px-xl-0">
                                <div class="d-none d-sm-block">
                                    <h2 class="h6 text-gray-400 mb-0"> Total Products</h2>
                                    <a href="{{ route('admin.products.index') }}">
                                        <div class="fw-extrabold mb-2">{{ $products }}</div>
                                    </a>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>
            </div>


            <div class="col-12 col-sm-6 col-xl-3 mb-4">
                <div class="card border-0 shadow">
                    <div class="card-body">
                        <div class="row d-block d-xl-flex align-items-center">
                            <div
                                class="col-12 col-xl-5 text-xl-center mb-3 mb-xl-0 d-flex align-items-center justify-content-xl-center">
                                <div class="icon-shape icon-shape-{{ $colores->random() }} rounded me-4 me-sm-0">

                                    <i class="fas fa-check-double icon"></i>
                                </div>
                                <div class="d-sm-none">
                                    <h2 class="h5">Products In Stock</h2>
                                    <div class="fw-extrabold mb-1">{{ $productsInStock }}</div>
                                </div>
                            </div>
                            <div class="col-12 col-xl-7 px-xl-0">
                                <div class="d-none d-sm-block">
                                    <h2 class="h6 text-gray-400 mb-0"> Products In Stock</h2>
                                    <a href="{{ route('admin.products.index', ['type' => 'in-stock']) }}">
                                        <div class="fw-extrabold mb-2">{{ $productsInStock }}</div>
                                    </a>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>
            </div>


            <div class="col-12 col-sm-6 col-xl-3 mb-4">
                <div class="card border-0 shadow">
                    <div class="card-body">
                        <div class="row d-block d-xl-flex align-items-center">
                            <div
                                class="col-12 col-xl-5 text-xl-center mb-3 mb-xl-0 d-flex align-items-center justify-content-xl-center">
                                <div class="icon-shape icon-shape-{{ $colores->random() }} rounded me-4 me-sm-0">

                                    <i class="fas fa-times icon"></i>
                                </div>
                                <div class="d-sm-none">
                                    <h2 class="h5">Products Out Of Stock</h2>
                                    <div class="fw-extrabold mb-1">{{ $productsOutStock }}</div>
                                </div>
                            </div>
                            <div class="col-12 col-xl-7 px-xl-0">
                                <div class="d-none d-sm-block">
                                    <h2 class="h6 text-gray-400 mb-0">Products Out Of Stock</h2>
                                    <a href="{{ route('admin.products.index', ['type' => 'out-stock']) }}">
                                        <div class="fw-extrabold mb-2">{{ $productsOutStock }}</div>
                                    </a>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>
            </div>









            <div class="col-12 col-sm-6 col-xl-3 mb-4">
                <div class="card border-0 shadow">
                    <div class="card-body">
                        <div class="row d-block d-xl-flex align-items-center">
                            <div
                                class="col-12 col-xl-5 text-xl-center mb-3 mb-xl-0 d-flex align-items-center justify-content-xl-center">
                                <div class="icon-shape icon-shape-{{ $colores->random() }} rounded me-4 me-sm-0">

                                    <i class="fas fa-gifts icon"></i>
                                </div>
                                <div class="d-sm-none">
                                    <h2 class="h5">Promo Codes</h2>
                                    <div class="fw-extrabold mb-1">{{ $promoCodes }}</div>
                                </div>
                            </div>
                            <div class="col-12 col-xl-7 px-xl-0">
                                <div class="d-none d-sm-block">
                                    <h2 class="h6 text-gray-400 mb-0">Promo Codes</h2>
                                    <a href="{{ route('admin.promo-codes.index') }}">
                                        <div class="fw-extrabold mb-2">{{ $promoCodes }}</div>
                                    </a>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>
            </div>




            <div class="col-12 col-sm-6 col-xl-3 mb-4">
                <div class="card border-0 shadow">
                    <div class="card-body">
                        <div class="row d-block d-xl-flex align-items-center">
                            <div
                                class="col-12 col-xl-5 text-xl-center mb-3 mb-xl-0 d-flex align-items-center justify-content-xl-center">
                                <div class="icon-shape icon-shape-{{ $colores->random() }} rounded me-4 me-sm-0">

                                    <i class="fas fa-envelope-open-text icon"></i>
                                </div>
                                <div class="d-sm-none">
                                    <h2 class="h5">New Messages</h2>
                                    <div class="fw-extrabold mb-1">{{ $messages }}</div>
                                </div>
                            </div>
                            <div class="col-12 col-xl-7 px-xl-0">
                                <div class="d-none d-sm-block">
                                    <h2 class="h6 text-gray-400 mb-0">New Messages</h2>
                                    <a href="{{ route('admin.contact-messages.index') }}">
                                        <div class="fw-extrabold mb-2">{{ $messages }}</div>
                                    </a>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>
            </div>


            <div class="col-12 col-sm-6 col-xl-3 mb-4">
                <div class="card border-0 shadow">
                    <div class="card-body">
                        <div class="row d-block d-xl-flex align-items-center">
                            <div
                                class="col-12 col-xl-5 text-xl-center mb-3 mb-xl-0 d-flex align-items-center justify-content-xl-center">
                                <div class="icon-shape icon-shape-{{ $colores->random() }} rounded me-4 me-sm-0">

                                    <i class="fas fa-envelope-open-text icon"></i>
                                </div>
                                <div class="d-sm-none">
                                    <h2 class="h5">Vendors Company</h2>
                                    <div class="fw-extrabold mb-1">{{ $vendorsCompanyCount }}</div>
                                </div>
                            </div>
                            <div class="col-12 col-xl-7 px-xl-0">
                                <div class="d-none d-sm-block">
                                    <h2 class="h6 text-gray-400 mb-0">Vendors Company</h2>
                                    <a href="{{ route('admin.contact-messages.index') }}">
                                        <div class="fw-extrabold mb-2">{{ $vendorsCompanyCount }}</div>
                                    </a>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-12 col-sm-6 col-xl-3 mb-4">
                <div class="card border-0 shadow">
                    <div class="card-body">
                        <div class="row d-block d-xl-flex align-items-center">
                            <div
                                class="col-12 col-xl-5 text-xl-center mb-3 mb-xl-0 d-flex align-items-center justify-content-xl-center">
                                <div class="icon-shape icon-shape-{{ $colores->random() }} rounded me-4 me-sm-0">

                                    <i class="fas fa-envelope-open-text icon"></i>
                                </div>
                                <div class="d-sm-none">
                                    <h2 class="h5">Vendors Individual</h2>
                                    <div class="fw-extrabold mb-1">{{ $vendorsIndividualCount }}</div>
                                </div>
                            </div>
                            <div class="col-12 col-xl-7 px-xl-0">
                                <div class="d-none d-sm-block">
                                    <h2 class="h6 text-gray-400 mb-0">Vendors Individual</h2>
                                    <a href="{{ route('admin.contact-messages.index') }}">
                                        <div class="fw-extrabold mb-2">{{ $vendorsIndividualCount }}</div>
                                    </a>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>
            </div>


    </div>

    {{-- orders --}}

    <div class="card my-4">

    <div class="card-header">
        With Draw Balance Per Month
    </div>
    <div class=" card-body ">

        <div class="d-flex justify-content-center align-items-center flex-wrap">


            <div class="card card-body px-1 py-3 mx-4 p bg-success   rounded my-3 order-statistics  position-relative" >

                <h1 style="color: #fff; font-size: 30px;">{{ number_format($total_order_budget) . " AED" }}</h1>


                <a>
                    <span class="d-block " style=" font-size:13px ; color:#fff">Total Events Balance</span>
                </a>
               </div>


           <div class="card card-body px-1 py-3 mx-4 p bg-info   rounded my-3 order-statistics  position-relative" >

            <h1 style="color: #fff; font-size: 30px;">{{ number_format($total_commission_budget) . " AED" }}</h1>


            <a><span class="d-block " style=" font-size:13px ; color:#fff">Our Commission From Vendors</span></a>
           </div>



           <div class="card card-body px-1 py-3 mx-4 p bg-primary   rounded my-3 order-statistics  position-relative" >

            <h1 style="color: #fff; font-size: 25px;">{{ number_format($total_vendor_budgets) . " AED" }}</h1>


            <a><span class="d-block " style=" font-size:13px ; color:#fff">Total Vendors Transactions</span></a>
           </div>
           <!---->
           <div class="card card-body px-1 py-3 mx-4 p bg-primary   rounded my-3 order-statistics  position-relative" >

            <h1 style="color: #fff; font-size: 30px;">0 AED</h1>


            <a><span class="d-block " style=" font-size:13px ; color:#fff">Final Events Balance</span></a>
           </div>





        </div>
    </div>
</div>

    <div class="card my-4">

        <div class="card-header">
            Products Orders
        </div>
        <div class=" card-body ">

            <div class="d-flex justify-content-center align-items-center flex-wrap">


                <div class="card card-body px-1 py-3 mx-4 p bg-info   rounded my-3 order-statistics  position-relative">

                    <i class="far fa-plus-square" style="margin-bottom: 10px ; font-size:30px"></i>


                    <a href="{{ route('admin.orders.newOrders') }}"><span class="d-block "
                            style=" font-size:20px ; color:#fff">New Orders</span></a>
                    <span class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger">
                        {{ $newOrdersCount }}
                    </span>
                </div>



                <div class="card card-body px-1 py-3 mx-4 p bg-primary   rounded my-3 order-statistics  position-relative">

                    <i class="fas fa-spinner spine" style="margin-bottom: 10px ; font-size:30px"></i>


                    <a href="{{ route('admin.orders.inprogressOrders') }}"><span class="d-block "
                            style=" font-size:20px ; color:#fff">Inprogress Orders</span></a>
                    <span class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger">
                        {{ $inprogressOrdersCount }}
                    </span>
                </div>



                <div class="card card-body px-1 py-3 mx-4 p bg-success   rounded my-3 order-statistics  position-relative">

                    <i class="fas fa-check-double" style="margin-bottom: 10px ; font-size:30px"></i>



                    <a href="{{ route('admin.orders.deliveredOrders') }}"><span class="d-block "
                            style=" font-size:20px ; color:#fff">Delivered Orders</span></a>
                    <span class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger">
                        {{ $deliveredOrdersCount }}
                    </span>
                </div>



                <div class="card card-body px-1 py-3 mx-4 p bg-danger   rounded my-3 order-statistics  position-relative">

                    <i class="fas fa-window-close" style="margin-bottom: 10px ; font-size:30px"></i>

                    <a href="{{ route('admin.orders.cancelledOrders') }}"><span class="d-block "
                            style=" font-size:20px ; color:#fff">Cancelled Orders</span></a>
                    <span class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-info">
                        {{ $cancelledOrdersCount }}
                    </span>
                </div>



            </div>
        </div>
    </div>




    {{-- orders --}}



    {{-- bookings --}}

    <div class="card my-4">

        <div class="card-header">
            Halls Bookings
        </div>

        <div class=" card-body ">

            <div class="d-flex justify-content-center align-items-center flex-wrap">








                <div
                    class="card card-body  py-3  p bg-success   rounded my-3 order-statistics  booking-statistics position-relative mx-4">

                    <i class="fa-regular fa-circle-check" style="margin-bottom: 10px ; font-size:30px"></i>

                    <a href="{{ route('admin.bookings.successfullBookings') }}"><span class="d-block "
                            style=" font-size:20px ; color:#fff">Successful Halls Bookings</span></a>
                    <span class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger">
                        {{ $successfullHallsBookings }}
                    </span>
                </div>



                <div
                    class="card card-body  py-3  p bg-danger   rounded my-3 order-statistics  booking-statistics position-relative mx-4">

                    <i class="fa-regular fa-circle-xmark" style="margin-bottom: 10px ; font-size:30px"></i>
                    <a href="{{ route('admin.bookings.cancelledBookings') }}"><span class="d-block "
                            style=" font-size:20px ; color:#fff">Cancelled Halls Bookings</span></a>
                    <span class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-info">
                        {{ $cancelledHallsBookings }}
                    </span>
                </div>



            </div>
        </div>
    </div>
@else
    <!--<div class="col-12 col-sm-6 col-xl-3 mb-4">-->
    <!--    <div class="card border-0 shadow">-->
    <!--        <div class="card-body">-->
    <!--            <div class="row d-block d-xl-flex align-items-center">-->
    <!--                <div-->
    <!--                    class="col-12 col-xl-5 text-xl-center mb-3 mb-xl-0 d-flex align-items-center justify-content-xl-center">-->
    <!--                    <div class="icon-shape icon-shape-{{ $colores->random() }} rounded me-4 me-sm-0">-->

    <!--                        <i class="fas fa-briefcase icon"></i>-->
    <!--                    </div>-->
    <!--                    <div class="d-sm-none">-->
    <!--                        <h2 class="h5">Vendors </h2>-->
    <!--                        <div class="fw-extrabold mb-1">{{ $vendors }}</div>-->
    <!--                    </div>-->
    <!--                </div>-->
    <!--                <div class="col-12 col-xl-7 px-xl-0">-->
    <!--                    <div class="d-none d-sm-block">-->
    <!--                        <h2 class="h6 text-gray-400 mb-0">Vendors </h2>-->
    <!--                        <a href="{{ route('admin.vendor-admins.index') }}">-->
    <!--                            <div class="fw-extrabold mb-2">{{ $vendors }}</div>-->
    <!--                        </a>-->
    <!--                    </div>-->

    <!--                </div>-->
    <!--            </div>-->
    <!--        </div>-->
    <!--    </div>-->
    <!--</div>-->

    @if ($vendor->type == 'hall' || $vendor->type == 'product_hall')
        <div class="col-12 col-sm-6 col-xl-3 mb-4">
            <div class="card border-0 shadow">
                <div class="card-body">
                    <div class="row d-block d-xl-flex align-items-center">
                        <div
                            class="col-12 col-xl-5 text-xl-center mb-3 mb-xl-0 d-flex align-items-center justify-content-xl-center">
                            <div class="icon-shape icon-shape-{{ $colores->random() }} rounded me-4 me-sm-0">

                                <i class="fa-solid fa-bars-staggered icon"></i>
                            </div>
                            <div class="d-sm-none">
                                <h2 class="h5">Halls Categories</h2>
                                <div class="fw-extrabold mb-1">{{ $hallCategories }}</div>
                            </div>
                        </div>
                        <div class="col-12 col-xl-7 px-xl-0">
                            <div class="d-none d-sm-block">
                                <h2 class="h6 text-gray-400 mb-0">Halls Categories</h2>
                                <a href="{{ route('admin.halls-categories.index') }}">
                                    <div class="fw-extrabold mb-2">{{ $hallCategories }}</div>
                                </a>
                            </div>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    @endif

    @if ($vendor->type == 'hall' || $vendor->type == 'product_hall')
        <div class="col-12 col-sm-6 col-xl-3 mb-4">
            <div class="card border-0 shadow">
                <div class="card-body">
                    <div class="row d-block d-xl-flex align-items-center">
                        <div
                            class="col-12 col-xl-5 text-xl-center mb-3 mb-xl-0 d-flex align-items-center justify-content-xl-center">
                            <div class="icon-shape icon-shape-{{ $colores->random() }} rounded me-4 me-sm-0">

                                <i class="fa-solid fa-wand-sparkles icon"></i>
                            </div>
                            <div class="d-sm-none">
                                <h2 class="h5">Halls</h2>
                                <div class="fw-extrabold mb-1">{{ $halls }}</div>
                            </div>
                        </div>
                        <div class="col-12 col-xl-7 px-xl-0">
                            <div class="d-none d-sm-block">
                                <h2 class="h6 text-gray-400 mb-0">Halls</h2>
                                <a href="{{ route('admin.halls.index') }}">
                                    <div class="fw-extrabold mb-2">{{ $halls }}</div>
                                </a>
                            </div>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    @endif

    <div class="col-12 col-sm-6 col-xl-3 mb-4">
        <div class="card border-0 shadow">
            <div class="card-body">
                <div class="row d-block d-xl-flex align-items-center">
                    <div
                        class="col-12 col-xl-5 text-xl-center mb-3 mb-xl-0 d-flex align-items-center justify-content-xl-center">
                        <div class="icon-shape icon-shape-{{ $colores->random() }} rounded me-4 me-sm-0">

                            <i class="fa-solid fa-money-bills icon"></i>
                        </div>
                        <div class="d-sm-none">
                            <h2 class="h5">Total Taxes</h2>
                            <div class="fw-extrabold mb-1">{{ $taxes }}</div>
                        </div>
                    </div>
                    <div class="col-12 col-xl-7 px-xl-0">
                        <div class="d-none d-sm-block">
                            <h2 class="h6 text-gray-400 mb-0">Total Taxes</h2>
                            <a href="{{ route('admin.taxes.index') }}">
                                <div class="fw-extrabold mb-2">{{ $taxes }}</div>
                            </a>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>


    <div class="col-12 col-sm-6 col-xl-3 mb-4">
        <div class="card border-0 shadow">
            <div class="card-body">
                <div class="row d-block d-xl-flex align-items-center">
                    <div
                        class="col-12 col-xl-5 text-xl-center mb-3 mb-xl-0 d-flex align-items-center justify-content-xl-center">
                        <div class="icon-shape icon-shape-{{ $colores->random() }} rounded me-4 me-sm-0">

                            <i class="fa-solid fa-truck-fast icon"></i>
                        </div>
                        <div class="d-sm-none">
                            <h2 class="h5">Total Shippings Fees</h2>
                            <div class="fw-extrabold mb-1">{{ $shippings }}</div>
                        </div>
                    </div>
                    <div class="col-12 col-xl-7 px-xl-0">
                        <div class="d-none d-sm-block">
                            <h2 class="h6 text-gray-400 mb-0"> Total Shippings Fees</h2>
                            <a href="{{ route('admin.shippings.index') }}">
                                <div class="fw-extrabold mb-2">{{ $shippings }}</div>
                            </a>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>

    @if ($vendor->type == 'product' || $vendor->type == 'product_hall')
        <div class="col-12 col-sm-6 col-xl-3 mb-4">
            <div class="card border-0 shadow">
                <div class="card-body">
                    <div class="row d-block d-xl-flex align-items-center">
                        <div
                            class="col-12 col-xl-5 text-xl-center mb-3 mb-xl-0 d-flex align-items-center justify-content-xl-center">
                            <div class="icon-shape icon-shape-{{ $colores->random() }} rounded me-4 me-sm-0">

                                <i class="fas fa-shopping-cart icon"></i>
                            </div>
                            <div class="d-sm-none">
                                <h2 class="h5"> Total Products</h2>
                                <div class="fw-extrabold mb-1">{{ $products }}</div>
                            </div>
                        </div>
                        <div class="col-12 col-xl-7 px-xl-0">
                            <div class="d-none d-sm-block">
                                <h2 class="h6 text-gray-400 mb-0"> Total Products</h2>
                                <a href="{{ route('admin.products.index') }}">
                                    <div class="fw-extrabold mb-2">{{ $products }}</div>
                                </a>
                            </div>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    @endif

    @if ($vendor->type == 'product' || $vendor->type == 'product_hall')
        <div class="col-12 col-sm-6 col-xl-3 mb-4">
            <div class="card border-0 shadow">
                <div class="card-body">
                    <div class="row d-block d-xl-flex align-items-center">
                        <div
                            class="col-12 col-xl-5 text-xl-center mb-3 mb-xl-0 d-flex align-items-center justify-content-xl-center">
                            <div class="icon-shape icon-shape-{{ $colores->random() }} rounded me-4 me-sm-0">

                                <i class="fas fa-shopping-cart icon"></i>
                            </div>
                            <div class="d-sm-none">
                                <h2 class="h5"> Products Categories</h2>
                                <div class="fw-extrabold mb-1">{{ $prodcats }}</div>
                            </div>
                        </div>
                        <div class="col-12 col-xl-7 px-xl-0">
                            <div class="d-none d-sm-block">
                                <h2 class="h6 text-gray-400 mb-0"> Products Categories</h2>
                                <a href="{{ route('admin.products-categories.index') }}">
                                    <div class="fw-extrabold mb-2">{{ $prodcats }}</div>
                                </a>
                            </div>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    @endif

    @if ($vendor->type == 'product' || $vendor->type == 'product_hall')
        <div class="col-12 col-sm-6 col-xl-3 mb-4">
            <div class="card border-0 shadow">
                <div class="card-body">
                    <div class="row d-block d-xl-flex align-items-center">
                        <div
                            class="col-12 col-xl-5 text-xl-center mb-3 mb-xl-0 d-flex align-items-center justify-content-xl-center">
                            <div class="icon-shape icon-shape-{{ $colores->random() }} rounded me-4 me-sm-0">

                                <i class="fas fa-check-double icon"></i>
                            </div>
                            <div class="d-sm-none">
                                <h2 class="h5">Products In Stock</h2>
                                <div class="fw-extrabold mb-1">{{ $productsInStock }}</div>
                            </div>
                        </div>
                        <div class="col-12 col-xl-7 px-xl-0">
                            <div class="d-none d-sm-block">
                                <h2 class="h6 text-gray-400 mb-0"> Products In Stock</h2>
                                <a href="{{ route('admin.products.index', ['type' => 'in-stock']) }}">
                                    <div class="fw-extrabold mb-2">{{ $productsInStock }}</div>
                                </a>
                            </div>

                        </div>
                    </div>
                </div>
            </div>
        </div>


        <div class="col-12 col-sm-6 col-xl-3 mb-4">
            <div class="card border-0 shadow">
                <div class="card-body">
                    <div class="row d-block d-xl-flex align-items-center">
                        <div
                            class="col-12 col-xl-5 text-xl-center mb-3 mb-xl-0 d-flex align-items-center justify-content-xl-center">
                            <div class="icon-shape icon-shape-{{ $colores->random() }} rounded me-4 me-sm-0">

                                <i class="fas fa-times icon"></i>
                            </div>
                            <div class="d-sm-none">
                                <h2 class="h5">Products Out Of Stock</h2>
                                <div class="fw-extrabold mb-1">{{ $productsOutStock }}</div>
                            </div>
                        </div>
                        <div class="col-12 col-xl-7 px-xl-0">
                            <div class="d-none d-sm-block">
                                <h2 class="h6 text-gray-400 mb-0">Products Out Of Stock</h2>
                                <a href="{{ route('admin.products.index', ['type' => 'out-stock']) }}">
                                    <div class="fw-extrabold mb-2">{{ $productsOutStock }}</div>
                                </a>
                            </div>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    @endif






    <div class="col-12 col-sm-6 col-xl-3 mb-4">
        <div class="card border-0 shadow">
            <div class="card-body">
                <div class="row d-block d-xl-flex align-items-center">
                    <div
                        class="col-12 col-xl-5 text-xl-center mb-3 mb-xl-0 d-flex align-items-center justify-content-xl-center">
                        <div class="icon-shape icon-shape-{{ $colores->random() }} rounded me-4 me-sm-0">

                            <i class="fas fa-gifts icon"></i>
                        </div>
                        <div class="d-sm-none">
                            <h2 class="h5">Promo Codes</h2>
                            <div class="fw-extrabold mb-1">{{ $promoCodes }}</div>
                        </div>
                    </div>
                    <div class="col-12 col-xl-7 px-xl-0">
                        <div class="d-none d-sm-block">
                            <h2 class="h6 text-gray-400 mb-0">Promo Codes</h2>
                            <a href="{{ route('admin.promo-codes.index') }}">
                                <div class="fw-extrabold mb-2">{{ $promoCodes }}</div>
                            </a>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>






    </div>

    {{-- orders --}}
    @if ($vendor->type == 'product' || $vendor->type == 'product_hall')
        <div class="card my-4">

            <div class="card-header">
                Products Orders
            </div>
            <div class=" card-body ">

                <div class="d-flex justify-content-center align-items-center flex-wrap">


                    <div
                        class="card card-body px-1 py-3 mx-4 p bg-info   rounded my-3 order-statistics  position-relative">

                        <i class="far fa-plus-square" style="margin-bottom: 10px ; font-size:30px"></i>


                        <a href="{{ route('admin.orders.newOrders') }}"><span class="d-block "
                                style=" font-size:20px ; color:#fff">New Orders</span></a>
                        <span class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger">
                            {{ $newOrdersCount }}
                        </span>
                    </div>



                    <div
                        class="card card-body px-1 py-3 mx-4 p bg-primary   rounded my-3 order-statistics  position-relative">

                        <i class="fas fa-spinner spine" style="margin-bottom: 10px ; font-size:30px"></i>


                        <a href="{{ route('admin.orders.inprogressOrders') }}"><span class="d-block "
                                style=" font-size:20px ; color:#fff">Inprogress Orders</span></a>
                        <span class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger">
                            {{ $inprogressOrdersCount }}
                        </span>
                    </div>



                    <div
                        class="card card-body px-1 py-3 mx-4 p bg-success   rounded my-3 order-statistics  position-relative">

                        <i class="fas fa-check-double" style="margin-bottom: 10px ; font-size:30px"></i>



                        <a href="{{ route('admin.orders.deliveredOrders') }}"><span class="d-block "
                                style=" font-size:20px ; color:#fff">Delivered Orders</span></a>
                        <span class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger">
                            {{ $deliveredOrdersCount }}
                        </span>
                    </div>



                    <div
                        class="card card-body px-1 py-3 mx-4 p bg-danger   rounded my-3 order-statistics  position-relative">

                        <i class="fas fa-window-close" style="margin-bottom: 10px ; font-size:30px"></i>

                        <a href="{{ route('admin.orders.cancelledOrders') }}"><span class="d-block "
                                style=" font-size:20px ; color:#fff">Cancelled Orders</span></a>
                        <span class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-info">
                            {{ $cancelledOrdersCount }}
                        </span>
                    </div>



                </div>
            </div>
        </div>
    @endif



    {{-- orders --}}



    {{-- bookings --}}
    @if ($vendor->type == 'hall' || $vendor->type == 'product_hall')
        <div class="card my-4">

            <div class="card-header">
                Halls Bookings
            </div>

            <div class=" card-body ">

                <div class="d-flex justify-content-center align-items-center flex-wrap">








                    <div
                        class="card card-body  py-3  p bg-success   rounded my-3 order-statistics  booking-statistics position-relative mx-4">

                        <i class="fa-regular fa-circle-check" style="margin-bottom: 10px ; font-size:30px"></i>

                        <a href="{{ route('admin.bookings.successfullBookings') }}"><span class="d-block "
                                style=" font-size:20px ; color:#fff">Successful Halls Bookings</span></a>
                        <span class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger">
                            {{ $successfullHallsBookings }}
                        </span>
                    </div>



                    <div
                        class="card card-body  py-3  p bg-danger   rounded my-3 order-statistics  booking-statistics position-relative mx-4">

                        <i class="fa-regular fa-circle-xmark" style="margin-bottom: 10px ; font-size:30px"></i>
                        <a href="{{ route('admin.bookings.cancelledBookings') }}"><span class="d-block "
                                style=" font-size:20px ; color:#fff">Cancelled Halls Bookings</span></a>
                        <span class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-info">
                            {{ $cancelledHallsBookings }}
                        </span>
                    </div>



                </div>
            </div>
        </div>
    @endif
    @endif




{{-- Current Month Income from Products --}}
    <div class="row">

        <div class="col-xl-12">
            <div class="card shadow mb-4">
                <!-- Card Header - Dropdown -->
                <div class="card-header d-flex flex-row align-items-center flex-0 border-bottom">

                    <div class="d-block">
                        <div class="h5 fw-normal text-gray mb-2">Current Month Total Income From Products </div>
                        <div class="h4 fw-extrabold text-success">{{ number_format(91050000) }} AED</div>
                    </div>

                </div>
                <!-- Card Body -->
                <div class="card-body">
                    <div class="chart-area my-3">
                        <canvas id="productsIncome"></canvas>
                    </div>
                </div>
            </div>
        </div>

        {{--  Current Month Income from Products --}}






    </div>







    <div class="row">
        <div class="col-12 col-xl-8">
            <div class="row">





                {{-- Current Month Orders --}}

                <div class="col-12">
                    <div class="card shadow mb-4">
                        <!-- Card Header - Dropdown -->

                        <div class="card-header d-flex flex-row align-items-center flex-0 border-bottom">

                            <div class="d-block">
                                <div class="h3 fw-normal text-gray mb-2">Current Month Orders</div>
                                <div class="h3 fw-extrabold text-success">{{number_format(251000)}} Order</div>
                            </div>

                        </div>
                        <!-- Card Body -->
                        <div class="card-body">
                            <div class="chart-area">
                                <canvas id="ordersChart"></canvas>
                            </div>
                        </div>
                    </div>
                </div>
                {{--  Current Month Orders --}}



                {{-- latest orders --}}

                <div class="col-12 mb-4">
                    <div class="card border-0 shadow">
                        <div class="card-header">
                            <div class="row align-items-center">
                                <div class="col">
                                    <h2 class="fs-5 fw-bold mb-0">Latest Orders</h2>
                                </div>
                                <div class="col text-end">
                                    <a href="#" class="btn btn-sm btn-primary">See all</a>
                                </div>
                            </div>
                        </div>
                        <div class="table-responsive">
                            <table class="table align-items-center table-flush">
                                <thead class="thead-light">
                                    <tr>
                                        <th class="border-bottom" scope="col">User Name</th>
                                        <th class="border-bottom" scope="col">Order Number</th>
                                        <th class="border-bottom" scope="col">Total</th>
                                        <th class="border-bottom" scope="col">Date</th>
                                        <th class="border-bottom" scope="col">Show</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <th class="text-gray-900" scope="row">
                                            Ahmed Eissa
                                        </th>
                                        <td class="fw-bolder text-gray-500">
                                            9838
                                        </td>
                                        <td class="fw-bolder text-gray-500">
                                            {{ number_format( 80000) }} AED
                                        </td>

                                        <td class="fw-bolder text-gray-500 ">


                                            <span class="d-block"><i class="fas fa-calendar-week text-info"></i>
                                                2023-01-22 </span>
                                            <span class="d-block"><i class="fas fa-clock text-success"></i> 06:23 PM
                                            </span>

                                        </td>

                                        <td class="fw-bolder text-gray-500">
                                            <a title="GO To Order" href="#"
                                                class="btn btn-sm btn-secondary d-inline-flex align-items-center">
                                                <i class="fas fa-eye icon icon-xxs "></i>
                                            </a>
                                        </td>
                                    </tr>

                                    <tr>
                                        <th class="text-gray-900" scope="row">
                                            Somaia Mostafa
                                        </th>
                                        <td class="fw-bolder text-gray-500">
                                            9628
                                        </td>
                                        <td class="fw-bolder text-gray-500">
                                            {{ number_format(44000) }} AED
                                        </td>
                                        <td class="fw-bolder text-gray-500">
                                            <span class="d-block"><i class="fas fa-calendar-week text-info"></i>
                                                2023-01-22 </span>
                                            <span class="d-block"><i class="fas fa-clock text-success"></i> 06:21 PM
                                            </span>
                                        </td>
                                        <td class="fw-bolder text-gray-500">
                                            <a title="GO To Order" href="#"
                                                class="btn btn-sm btn-secondary d-inline-flex align-items-center">
                                                <i class="fas fa-eye icon icon-xxs "></i>
                                            </a>
                                        </td>
                                    </tr>


                                    <tr>
                                        <th class="text-gray-900" scope="row">
                                            Alaa Ahmed
                                        </th>
                                        <td class="fw-bolder text-gray-500">
                                            9898
                                        </td>
                                        <td class="fw-bolder text-gray-500">
                                            {{ number_format( 70000) }} AED
                                        </td>
                                        <td class="fw-bolder text-gray-500">
                                            <span class="d-block"><i class="fas fa-calendar-week text-info"></i>
                                                2023-01-22 </span>
                                            <span class="d-block"><i class="fas fa-clock text-success"></i> 06:20 PM
                                            </span>
                                        </td>
                                        <td class="fw-bolder text-gray-500">
                                            <a title="GO To Order" href="#"
                                                class="btn btn-sm btn-secondary d-inline-flex align-items-center">
                                                <i class="fas fa-eye icon icon-xxs "></i>
                                            </a>
                                        </td>
                                    </tr>


                                    <tr>
                                        <th class="text-gray-900" scope="row">
                                            Reda Mohamed
                                        </th>
                                        <td class="fw-bolder text-gray-500">
                                            9098
                                        </td>
                                        <td class="fw-bolder text-gray-500">
                                            {{ number_format(120000) }} AED
                                        </td>
                                        <td class="fw-bolder text-gray-500">
                                            <span class="d-block"><i class="fas fa-calendar-week text-info"></i>
                                                2023-01-22 </span>
                                            <span class="d-block"><i class="fas fa-clock text-success"></i> 06:19 PM
                                            </span>
                                        </td>
                                        <td class="fw-bolder text-gray-500">
                                            <a title="GO To Order" href="#"
                                                class="btn btn-sm btn-secondary d-inline-flex align-items-center">
                                                <i class="fas fa-eye icon icon-xxs "></i>
                                            </a>
                                        </td>
                                    </tr>


                                    <tr>
                                        <th class="text-gray-900" scope="row">
                                            Rania Gamal
                                        </th>
                                        <td class="fw-bolder text-gray-500">
                                            9898
                                        </td>
                                        <td class="fw-bolder text-gray-500">
                                            {{ number_format (134000) }} AED
                                        </td>
                                        <td class="fw-bolder text-gray-500">
                                            <span class="d-block"><i class="fas fa-calendar-week text-info"></i>
                                                2023-01-22 </span>
                                            <span class="d-block"><i class="fas fa-clock text-success"></i> 06:18 PM
                                            </span>
                                        </td>
                                        <td class="fw-bolder text-gray-500">
                                            <a title="GO To Order" href="#"
                                                class="btn btn-sm btn-secondary d-inline-flex align-items-center">
                                                <i class="fas fa-eye icon icon-xxs "></i>
                                            </a>
                                        </td>
                                    </tr>

                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>

                {{-- latest orders --}}






            </div>
        </div>
        <div class="col-12 col-xl-4">



            <div class="col-12 px-0 mb-4">
                <div class="card border-0 shadow">
                    <div class="card-header d-flex flex-row align-items-center flex-0 border-bottom">
                        <div class="d-block">
                            <div class="h6 fw-normal text-gray mb-2">Orders Status</div>

                        </div>

                    </div>
                    <div class="card-body py-4">

                        <div class="chart-area">
                            <canvas id="ordersStatusChart"></canvas>
                        </div>

                    </div>
                </div>
            </div>




            <div class="col-12 px-0 mb-4">
                <div class="card border-0 shadow">
                    <div class="card-header d-flex flex-row align-items-center flex-0 border-bottom">
                        <div class="d-block">
                            <div class="h6 fw-normal text-gray mb-2">All Products</div>
                            <div class="h3 fw-extrabold text-warning">{{ number_format(300000) }} Product</div>

                        </div>

                    </div>
                    <div class="card-body py-4">

                        <div class="chart-area">
                            <canvas id="productsChart"></canvas>
                        </div>

                    </div>
                </div>
            </div>


        </div>
    </div>

@endsection




@section('scripts')
    <!-- ChartJS -->
    {{-- <script src={{ asset('dashboard/js/plugin/Chart.min.js') }}></script> --}}
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

    <script src="https://www.gstatic.com/firebasejs/8.10.1/firebase.js"></script>
    <script>
        var firebaseConfig = {
            apiKey: "AIzaSyBOUb8GvhXA6EPyGH5hDvEeHao9V6rfriE",
            authDomain: "events-73956.firebaseapp.com",
            projectId: "events-73956",
            storageBucket: "events-73956.appspot.com",
            messagingSenderId: "321122743257",
            appId: "1:321122743257:web:6e28abd35a11888f6f5fc8",
            measurementId: "G-ZW7E04G5ZF",
        };
        firebase.initializeApp(firebaseConfig);
        const messaging = firebase.messaging();
        console.log('script')
        let csrf = `{{ csrf_token() }}`

        function startFCM() {
            console.log('STARTFCM')
            messaging.requestPermission().then(() => {
                return messaging.getToken({
                    vapidKey: 'BMJEW2gMO0QC05QwvLTq8KsF8RcHNGIVWLvAzK-Y9EepXKxe9ZfycMg3qvc4Ajq1kMmaawrMm6plMvt3FZhZ-FI'
                })
            }).then(function(response) {
                console.log(response, 'test')
                $.ajaxSetup({
                    headers: {
                        'X-CSRF-TOKEN': csrf,
                    }
                });
                $.ajax({
                    url: '{{ route('admin.updateAdminToken') }}',
                    type: 'POST',
                    data: {
                        token: response
                    },
                    dataType: 'JSON',
                    success: function(response) {
                        // alert('Token stored.');
                    },
                    error: function(error) {
                        console.log('error', error)
                        // alert(error);
                    },
                });
            }).catch(function(error) {
                console.log('error catch', error)
                // alert(error);
            });
        }
        // messaging.getToken( {vapidKey: 'BPVvFQt3edIpTAp9C0-osAs_SSWzlqno6QT-pA4nbHWYplEGUgbdeOL1ooQz9FGlnCwrdJmMttJnpzoxNauZkls'})
        //     .then((currentToken) => {
        //
        //         if (currentToken) {
        //             console.log(updateTokenAPI,currentToken,csrfToken)
        //             // console.log('current token for client: ', currentToken);
        //             // Perform any other neccessary action with the token
        //             $.ajax({
        //                     url:updateTokenAPI,
        //                     method: 'post',
        //                     data: {
        //                         "_token":csrfToken,
        //                         "firebaseToken": currentToken
        //                     },
        //                     headers:{
        //                         "Accept":"application/json",
        //                         "X-CSRF-TOKEN":csrfToken
        //                     },
        //                     dataType:"json",
        //                     success:function(data){
        //                         console.log(data)
        //                     }
        //                 }
        //             )
        //             console.log('ajax called')
        //         } else {
        //             // Show permission request UI
        //             console.log('No registration token available. Request permission to generate one.');
        //         }
        //     })
        //     .catch((err) => {
        //         console.log('An error occurred while retrieving token. ', err);
        //     });


        startFCM();
        messaging.onMessage(function(payload) {
            // console.log(payload, 'notificationOnMessage')
            $('.notificationCounter').html(parseInt($('.notificationCounter').html()) + 1)
            // const title = payload.notification.title;
            // const options = {
            //     body: payload.notification.body,
            //     icon: payload.notification.icon,
            // };
            // new Notification(title, options);
            var audio = document.createElement("AUDIO")
            document.body.appendChild(audio);
            audio.src = "{{ asset('assets/dashboard/sound/mixkit-bell-notification-933.wav') }}"
            // audio.play();
            audio.addEventListener("canplaythrough", () => {
                audio.play().catch(e => {

                    window.addEventListener('click', () => {
                        audio.play()
                    }, {
                        once: true
                    })
                })
            });
        });
    </script>


    <script>
        function read() {
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': "{{ csrf_token() }}"
                }
            });
            $.get("update", function(status, xhr) {
                document.getElementById("badge").classList.remove('badge-danger');
                console.log("success");
            })
        }
    </script>

    <script>
        // currentMonthIncomFromProducts
        let currentMonthIncomFromProductsCTX = document.getElementById("productsIncome");



        const currentMonthIncomFromProductsData = {
            labels: ['1 Jan', '2 Jan', '3 Jan', '4 Jan', '5 Jan', '6 Jan', '7 Jan', '8 Jan', '9 Jan', '10 Jan',
                '11 Jan', '12 Jan', '13 Jan', '14 Jan', '15 Jan', '16 Jan', '17 Jan', '18 Jan', '19 Jan', '20 Jan',
                '21 Jan', '22 Jan', '23 Jan', '24 Jan', '25 Jan', '26 Jan', '27 Jan', '28 Jan', '29 Jan', '30 Jan'
            ],
            datasets: [{
                label: 'AED',
                data: ['20000', '40000', '60000', '10000', '60000', '50000', '90000', '11000', '14000', '22000',
                    '12000', '23000', '30000', '40000', '22000', '33000', '21000', '20000', '40000',
                    '60000', '10000', '60000', '50000', '90000', '11000', '14000', '22000', '12000',
                    '23000', '30000', '40000', '22000', '33000', '21000', "1000"
                ],

                //   pointStyle: 'star',
                //   pointRadius: 10,
                //   pointHoverRadius: 15
            }]
        };
        const currentMonthIncomFromProductsConfig = {
            type: 'line',
            data: currentMonthIncomFromProductsData,
            options: {
                responsive: true,
                plugins: {
                    title: {
                        display: true,
                        text: (currentMonthIncomFromProductsCTX) =>
                            'Current Month Total Income From Products Is 910,500,00 AED',
                    }
                }
            }
        };

        new Chart(currentMonthIncomFromProductsCTX, currentMonthIncomFromProductsConfig);

        // currentMonthIncomFromProducts


        // currentMonthIncomFromBookings
        let currentMonthIncomFromBookingsCTX = document.getElementById("bookinksIncome");



        const currentMonthIncomFromBookingsData = {
            labels: ['1 Jan', '2 Jan', '3 Jan', '4 Jan', '5 Jan', '6 Jan', '7 Jan', '8 Jan', '9 Jan', '10 Jan',
                '11 Jan', '12 Jan', '13 Jan', '14 Jan', '15 Jan', '16 Jan', '17 Jan', '18 Jan', '19 Jan', '20 Jan',
                '21 Jan', '22 Jan', '23 Jan', '24 Jan', '25 Jan', '26 Jan', '27 Jan', '28 Jan', '29 Jan', '30 Jan'
            ],
            datasets: [{
                label: 'AED',
                data: ['30000', '50000', '80000', '20000', '20000', '10000', '20000', '18000', '11000', '29000',
                    '11000', '23000', '10000', '90000', '29000', '35000', '3000', '30000', '50000', '80000',
                    '20000', '20000', '10000', '20000', '18000', '11000', '29000', '11000', '23000',
                    '10000', '90000', '29000', '35000', '3000'
                ],

                //   pointStyle: 'circle',
                //   pointRadius: 10,
                //   pointHoverRadius: 15,

                backgroundColor: [
                    '#0d6efd',
                    '#0dcaf0',
                    '#2ecc71',
                    '#dc3545',
                ]
            }]
        };
        const currentMonthIncomFromBookingsConfig = {
            type: 'line',
            data: currentMonthIncomFromBookingsData,
            options: {
                responsive: true,
                plugins: {
                    title: {
                        display: true,
                        text: (currentMonthIncomFromBookingsCTX) =>
                            'Current Month Total Income From Bookings Is 1,110,500,00  AED',
                    }
                }
            }
        };

        new Chart(currentMonthIncomFromBookingsCTX, currentMonthIncomFromBookingsConfig);

        // currentMonthIncomFromProducts




        // currentMonthOrders
        let currentMonthOrdersCTX = document.getElementById("ordersChart");

        const currentMonthOrdersData = {
            labels: ['1 Jan', '2 Jan', '3 Jan', '4 Jan', '5 Jan', '6 Jan', '7 Jan', '8 Jan', '9 Jan', '10 Jan',
                '11 Jan', '12 Jan', '13 Jan', '14 Jan', '15 Jan', '16 Jan', '17 Jan', '18 Jan', '19 Jan', '20 Jan',
                '21 Jan', '22 Jan', '23 Jan', '24 Jan', '25 Jan', '26 Jan', '27 Jan', '28 Jan', '29 Jan', '30 Jan'
            ],
            datasets: [{
                label: 'Orders',
                data: ['200', '400', '600', '100', '600', '500', '900', '100', '400', '300', '800', '900',
                    '1000', '1200', '2000', '300', '2200', '200', '400', '600', '100', '600', '500', '900',
                    '100', '400', '300', '800', '900', '1000', '1200', '2000', '300', '2200'
                ],

                pointStyle: 'circle',
                pointRadius: 10,
                pointHoverRadius: 15
            }]
        };
        const currentMonthOrdersConfig = {
            type: 'bar',
            data: currentMonthOrdersData,
            options: {
                responsive: true,
                plugins: {
                    title: {
                        display: true,
                        text: (ctx) => 'Current Month  Total Orders Is 2,510,00 ',
                    }
                }
            }
        };

        new Chart(currentMonthOrdersCTX, currentMonthOrdersConfig);

        // currentMonthOrders
        // product chart

        let ctx3 = document.getElementById("productsChart");

        const data3 = {
            labels: ['In Stock', 'Out Of Stock', ],
            datasets: [{
                label: 'Products',
                data: ['1800', '1200'],

                pointStyle: 'circle',
                pointRadius: 10,
                pointHoverRadius: 15
            }]
        };
        const config3 = {
            type: 'pie',
            data: data3,
            options: {
                responsive: true,
                plugins: {
                    title: {
                        display: true,
                        text: (ctx) => 'Total Products Is 3,000,00 Product ',
                    }
                }
            }

        };
        new Chart(ctx3, config3);
        // product chart

        // ordersStatusChart


        let ctx4 = document.getElementById("ordersStatusChart");

        const data4 = {
            labels: ['New', 'Inprogress', 'Delivered', 'Cancelled'],
            datasets: [{
                label: 'Order',
                data: ['999', '992', '5000', '99'],

                pointStyle: 'circle',
                pointRadius: 10,
                pointHoverRadius: 15,
                backgroundColor: [
                    '#0d6efd',
                    '#0dcaf0',
                    '#2ecc71',
                    '#dc3545',
                ]

            }]
        };
        const config4 = {
            type: 'pie',
            data: data4,
            options: {
                responsive: true,
                plugins: {
                    title: {
                        display: true,
                        text: (ctx) => 'Total Orders Is 3,000,00 Order ',
                    },

                }
            }

        };
        new Chart(ctx4, config4);

        // ordersStatusChart
    </script>
@endsection
