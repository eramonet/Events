@extends('layouts.admin.master')

@section('content')
    <div class="py-4">

        <div class="d-flex justify-content-between w-100 flex-wrap">
            <div class="mb-3 mb-lg-0">
                <h1 class="h4"> <i class="fa fa-house"></i> {{ config('app.name') }} Admin Dashboard </h1>

            </div>

        </div>
    </div>

    <div class="row dashboard-home-top">


    @php
            $colores = collect(['primary', 'secondary', 'success', 'danger', 'warning', 'info', 'light', 'tertiary']);
         @endphp

        <div class="col-12 col-sm-6 col-xl-3 mb-4">
            <div class="card border-0 shadow">
                <div class="card-body">
                    <div class="row d-block d-xl-flex align-items-center">
                        <div
                            class="col-12 col-xl-5 text-xl-center mb-3 mb-xl-0 d-flex align-items-center justify-content-xl-center">
                            <div class="icon-shape icon-shape-{{ $colores->random() }} rounded me-4 me-sm-0">

                                <i class="fas fa-users icon"></i>
                            </div>
                            <div class="d-sm-none">
                                <h2 class="h5">Users</h2>

                                <div class="fw-extrabold mb-1"> <a href="#">{{ $usersCount }}</a></div>
                            </div>
                        </div>
                        <div class="col-12 col-xl-7 px-xl-0">
                            <div class="d-none d-sm-block">
                                <h2 class="h6 text-gray-400 mb-0">Users</h2>
                                <a href="{{ route('admin.users.index') }}">
                                    <div class="fw-extrabold mb-1">{{ $usersCount }}</div>
                                </a>
                            </div>

                        </div>
                    </div>
                </div>
            </div>
        </div>


        <div class="col-12 col-sm-6 col-xl-3 mb-4">
            <div class="card border-0 shadow">
                <div class="card-body">
                    <div class="row d-block d-xl-flex align-items-center">
                        <div
                            class="col-12 col-xl-5 text-xl-center mb-3 mb-xl-0 d-flex align-items-center justify-content-xl-center">
                            <div class="icon-shape icon-shape-{{ $colores->random() }} rounded me-4 me-sm-0">

                                <i class="fas fa-users-cog icon"></i>
                            </div>
                            <div class="d-sm-none">
                                <h2 class="h5">System Admins</h2>
                                <div class="fw-extrabold mb-1">{{ $adminsCount }}</div>
                            </div>
                        </div>
                        <div class="col-12 col-xl-7 px-xl-0">
                            <div class="d-none d-sm-block">
                                <h2 class="h6 text-gray-400 mb-0">System Admins</h2>
                                <a href="{{ route('admin.admins.index') }}">
                                    <div class="fw-extrabold mb-2">{{ $adminsCount }}</div>
                                </a>
                            </div>

                        </div>
                    </div>
                </div>
            </div>
        </div>



        <div class="col-12 col-sm-6 col-xl-3 mb-4">
            <div class="card border-0 shadow">
                <div class="card-body">
                    <div class="row d-block d-xl-flex align-items-center">
                        <div
                            class="col-12 col-xl-5 text-xl-center mb-3 mb-xl-0 d-flex align-items-center justify-content-xl-center">
                            <div class="icon-shape icon-shape-{{ $colores->random() }} rounded me-4 me-sm-0">

                                <i class="fa-solid fa-money-bills icon"></i>
                            </div>
                            <div class="d-sm-none">
                                <h2 class="h5">Total Taxes</h2>
                                <div class="fw-extrabold mb-1">{{ $taxes }}</div>
                            </div>
                        </div>
                        <div class="col-12 col-xl-7 px-xl-0">
                            <div class="d-none d-sm-block">
                                <h2 class="h6 text-gray-400 mb-0">Total Taxes</h2>
                                <a href="{{ route('admin.taxes.index') }}">
                                    <div class="fw-extrabold mb-2">{{ $taxes }}</div>
                                </a>
                            </div>

                        </div>
                    </div>
                </div>
            </div>
        </div>


        <div class="col-12 col-sm-6 col-xl-3 mb-4">
            <div class="card border-0 shadow">
                <div class="card-body">
                    <div class="row d-block d-xl-flex align-items-center">
                        <div
                            class="col-12 col-xl-5 text-xl-center mb-3 mb-xl-0 d-flex align-items-center justify-content-xl-center">
                            <div class="icon-shape icon-shape-{{ $colores->random() }} rounded me-4 me-sm-0">

                                <i class="fas fa-shopping-cart icon"></i>
                            </div>
                            <div class="d-sm-none">
                                <h2 class="h5"> Total Products</h2>
                                <div class="fw-extrabold mb-1">{{ $products }}</div>
                            </div>
                        </div>
                        <div class="col-12 col-xl-7 px-xl-0">
                            <div class="d-none d-sm-block">
                                <h2 class="h6 text-gray-400 mb-0"> Total Products</h2>
                                <a href="{{ route('admin.products.index') }}">
                                    <div class="fw-extrabold mb-2">{{ $products }}</div>
                                </a>
                            </div>

                        </div>
                    </div>
                </div>
            </div>
        </div>


        <div class="col-12 col-sm-6 col-xl-3 mb-4">
            <div class="card border-0 shadow">
                <div class="card-body">
                    <div class="row d-block d-xl-flex align-items-center">
                        <div
                            class="col-12 col-xl-5 text-xl-center mb-3 mb-xl-0 d-flex align-items-center justify-content-xl-center">
                            <div class="icon-shape icon-shape-{{ $colores->random() }} rounded me-4 me-sm-0">

                                <i class="fas fa-check-double icon"></i>
                            </div>
                            <div class="d-sm-none">
                                <h2 class="h5">Products In Stock</h2>
                                <div class="fw-extrabold mb-1">{{ $productsInStock }}</div>
                            </div>
                        </div>
                        <div class="col-12 col-xl-7 px-xl-0">
                            <div class="d-none d-sm-block">
                                <h2 class="h6 text-gray-400 mb-0"> Products In Stock</h2>
                                <a href="{{ route('admin.products.index', ['type' => 'in-stock']) }}">
                                    <div class="fw-extrabold mb-2">{{ $productsInStock }}</div>
                                </a>
                            </div>

                        </div>
                    </div>
                </div>
            </div>
        </div>


        <div class="col-12 col-sm-6 col-xl-3 mb-4">
            <div class="card border-0 shadow">
                <div class="card-body">
                    <div class="row d-block d-xl-flex align-items-center">
                        <div
                            class="col-12 col-xl-5 text-xl-center mb-3 mb-xl-0 d-flex align-items-center justify-content-xl-center">
                            <div class="icon-shape icon-shape-{{ $colores->random() }} rounded me-4 me-sm-0">

                                <i class="fas fa-times icon"></i>
                            </div>
                            <div class="d-sm-none">
                                <h2 class="h5">Products Out Of Stock</h2>
                                <div class="fw-extrabold mb-1">{{ $productsOutStock }}</div>
                            </div>
                        </div>
                        <div class="col-12 col-xl-7 px-xl-0">
                            <div class="d-none d-sm-block">
                                <h2 class="h6 text-gray-400 mb-0">Products Out Of Stock</h2>
                                <a href="{{ route('admin.products.index', ['type' => 'out-stock']) }}">
                                    <div class="fw-extrabold mb-2">{{ $productsOutStock }}</div>
                                </a>
                            </div>

                        </div>
                    </div>
                </div>
            </div>
        </div>









        <div class="col-12 col-sm-6 col-xl-3 mb-4">
            <div class="card border-0 shadow">
                <div class="card-body">
                    <div class="row d-block d-xl-flex align-items-center">
                        <div
                            class="col-12 col-xl-5 text-xl-center mb-3 mb-xl-0 d-flex align-items-center justify-content-xl-center">
                            <div class="icon-shape icon-shape-{{ $colores->random() }} rounded me-4 me-sm-0">

                                <i class="fas fa-gifts icon"></i>
                            </div>
                            <div class="d-sm-none">
                                <h2 class="h5">Promo Codes</h2>
                                <div class="fw-extrabold mb-1">{{ $promoCodes }}</div>
                            </div>
                        </div>
                        <div class="col-12 col-xl-7 px-xl-0">
                            <div class="d-none d-sm-block">
                                <h2 class="h6 text-gray-400 mb-0">Promo Codes</h2>
                                <a href="{{ route('admin.promo-codes.index') }}">
                                    <div class="fw-extrabold mb-2">{{ $promoCodes }}</div>
                                </a>
                            </div>

                        </div>
                    </div>
                </div>
            </div>
        </div>




        <div class="col-12 col-sm-6 col-xl-3 mb-4">
            <div class="card border-0 shadow">
                <div class="card-body">
                    <div class="row d-block d-xl-flex align-items-center">
                        <div
                            class="col-12 col-xl-5 text-xl-center mb-3 mb-xl-0 d-flex align-items-center justify-content-xl-center">
                            <div class="icon-shape icon-shape-{{ $colores->random() }} rounded me-4 me-sm-0">

                                <i class="fas fa-envelope-open-text icon"></i>
                            </div>
                            <div class="d-sm-none">
                                <h2 class="h5">New Messages</h2>
                                <div class="fw-extrabold mb-1">{{ $messages }}</div>
                            </div>
                        </div>
                        <div class="col-12 col-xl-7 px-xl-0">
                            <div class="d-none d-sm-block">
                                <h2 class="h6 text-gray-400 mb-0">New Messages</h2>
                                <a href="{{ route('admin.contact-messages.index') }}">
                                    <div class="fw-extrabold mb-2">{{ $messages }}</div>
                                </a>
                            </div>

                        </div>
                    </div>
                </div>
            </div>
        </div>



    </div>

    {{-- orders --}}



    <div class="card my-4">

        <div class="card-header">
            Products Orders
        </div>
        <div class=" card-body ">

            <div class="d-flex justify-content-center align-items-center flex-wrap">


                <div class="card card-body px-1 py-3 mx-4 p bg-info   rounded my-3 order-statistics  position-relative">

                    <i class="far fa-plus-square" style="margin-bottom: 10px ; font-size:30px"></i>


                    <a href="{{ route('admin.orders.newOrders') }}"><span class="d-block "
                            style=" font-size:20px ; color:#fff">New Orders</span></a>
                    <span class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger">
                        {{ $newOrdersCount }}
                    </span>
                </div>



                <div class="card card-body px-1 py-3 mx-4 p bg-primary   rounded my-3 order-statistics  position-relative">

                    <i class="fas fa-spinner spine" style="margin-bottom: 10px ; font-size:30px"></i>


                    <a href="{{ route('admin.orders.inprogressOrders') }}"><span class="d-block "
                            style=" font-size:20px ; color:#fff">Inprogress Orders</span></a>
                    <span class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger">
                        {{ $inprogressOrdersCount }}
                    </span>
                </div>



                <div class="card card-body px-1 py-3 mx-4 p bg-success   rounded my-3 order-statistics  position-relative">

                    <i class="fas fa-check-double" style="margin-bottom: 10px ; font-size:30px"></i>



                    <a href="{{ route('admin.orders.deliveredOrders') }}"><span class="d-block "
                            style=" font-size:20px ; color:#fff">Delivered Orders</span></a>
                    <span class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger">
                        {{ $deliveredOrdersCount }}
                    </span>
                </div>



                <div class="card card-body px-1 py-3 mx-4 p bg-danger   rounded my-3 order-statistics  position-relative">

                    <i class="fas fa-window-close" style="margin-bottom: 10px ; font-size:30px"></i>

                    <a href="{{ route('admin.orders.cancelledOrders') }}"><span class="d-block "
                            style=" font-size:20px ; color:#fff">Cancelled Orders</span></a>
                    <span class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-info">
                        {{ $cancelledOrdersCount }}
                    </span>
                </div>



            </div>
        </div>
    </div>




    {{-- orders --}}



    {{-- bookings --}}









    <div class="col-12 col-sm-6 col-xl-3 mb-4">
        <div class="card border-0 shadow">
            <div class="card-body">
                <div class="row d-block d-xl-flex align-items-center">
                    <div
                        class="col-12 col-xl-5 text-xl-center mb-3 mb-xl-0 d-flex align-items-center justify-content-xl-center">
                        <div class="icon-shape icon-shape-{{ $colores->random() }} rounded me-4 me-sm-0">

                            <i class="fas fa-gifts icon"></i>
                        </div>
                        <div class="d-sm-none">
                            <h2 class="h5">Promo Codes</h2>
                            <div class="fw-extrabold mb-1">{{ $promoCodes }}</div>
                        </div>
                    </div>
                    <div class="col-12 col-xl-7 px-xl-0">
                        <div class="d-none d-sm-block">
                            <h2 class="h6 text-gray-400 mb-0">Promo Codes</h2>
                            <a href="{{ route('admin.promo-codes.index') }}">
                                <div class="fw-extrabold mb-2">{{ $promoCodes }}</div>
                            </a>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>






    </div>

    {{-- orders --}}
         <div class="card my-4">

            <div class="card-header">
                Products Orders
            </div>
            <div class=" card-body ">

                <div class="d-flex justify-content-center align-items-center flex-wrap">


                    <div
                        class="card card-body px-1 py-3 mx-4 p bg-info   rounded my-3 order-statistics  position-relative">

                        <i class="far fa-plus-square" style="margin-bottom: 10px ; font-size:30px"></i>


                        <a href="{{ route('admin.orders.newOrders') }}"><span class="d-block "
                                style=" font-size:20px ; color:#fff">New Orders</span></a>
                        <span class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger">
                            {{ $newOrdersCount }}
                        </span>
                    </div>



                    <div
                        class="card card-body px-1 py-3 mx-4 p bg-primary   rounded my-3 order-statistics  position-relative">

                        <i class="fas fa-spinner spine" style="margin-bottom: 10px ; font-size:30px"></i>


                        <a href="{{ route('admin.orders.inprogressOrders') }}"><span class="d-block "
                                style=" font-size:20px ; color:#fff">Inprogress Orders</span></a>
                        <span class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger">
                            {{ $inprogressOrdersCount }}
                        </span>
                    </div>



                    <div
                        class="card card-body px-1 py-3 mx-4 p bg-success   rounded my-3 order-statistics  position-relative">

                        <i class="fas fa-check-double" style="margin-bottom: 10px ; font-size:30px"></i>



                        <a href="{{ route('admin.orders.deliveredOrders') }}"><span class="d-block "
                                style=" font-size:20px ; color:#fff">Delivered Orders</span></a>
                        <span class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger">
                            {{ $deliveredOrdersCount }}
                        </span>
                    </div>



                    <div
                        class="card card-body px-1 py-3 mx-4 p bg-danger   rounded my-3 order-statistics  position-relative">

                        <i class="fas fa-window-close" style="margin-bottom: 10px ; font-size:30px"></i>

                        <a href="{{ route('admin.orders.cancelledOrders') }}"><span class="d-block "
                                style=" font-size:20px ; color:#fff">Cancelled Orders</span></a>
                        <span class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-info">
                            {{ $cancelledOrdersCount }}
                        </span>
                    </div>



                </div>
            </div>
        </div>



    {{-- orders --}}



    {{-- bookings --}}





    {{-- Current Month Income from Products --}}
    <div class="row">

        <div class="col-xl-12">
            <div class="card shadow mb-4">
                <!-- Card Header - Dropdown -->
                <div class="card-header d-flex flex-row align-items-center flex-0 border-bottom">

                    <div class="d-block">
                        <div class="h5 fw-normal text-gray mb-2">Current Month Total Income From Products </div>
                        <div class="h4 fw-extrabold text-success">{{ number_format(91050000) }} AED</div>
                    </div>

                </div>
                <!-- Card Body -->
                <div class="card-body">
                    <div class="chart-area my-3">
                        <canvas id="productsIncome"></canvas>
                    </div>
                </div>
            </div>
        </div>

        {{--  Current Month Income from Products --}}






    </div>




@endsection




@section('scripts')
    <!-- ChartJS -->
    <script src={{ asset('dashboard/js/plugin/Chart.min.js') }}></script>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

    <script src="https://www.gstatic.com/firebasejs/8.10.1/firebase.js"></script>


    <script>
        // currentMonthIncomFromProducts
        let currentMonthIncomFromProductsCTX = document.getElementById("productsIncome");



        const currentMonthIncomFromProductsData = {
              labels: [
            @foreach ($ordersChart as $userCount )
              '{{ $userCount-> date }}',
            @endforeach

            ],
            datasets: [{
                label: 'Orders',
                data: [
                    @foreach ($ordersChart as $userCount )
              {{ $userCount-> count }},
            @endforeach
                ],

                pointStyle: 'circle',
                pointRadius: 10,
                pointHoverRadius: 15
            }]
        };
        const currentMonthIncomFromProductsConfig = {
            type: 'line',
            data: currentMonthIncomFromProductsData,
            options: {
                responsive: true,
                plugins: {
                    title: {
                        display: true,
                        text: (currentMonthIncomFromProductsCTX) =>
                            'Current Month Total Income From Products Is 910,500,00 AED',
                    }
                }
            }
        };

        new Chart(currentMonthIncomFromProductsCTX, currentMonthIncomFromProductsConfig);

        // currentMonthIncomFromProducts


        // currentMonthIncomFromBookings
        let currentMonthIncomFromBookingsCTX = document.getElementById("bookinksIncome");



        const currentMonthIncomFromBookingsData = {
            labels: ['1 Jan', '2 Jan', '3 Jan', '4 Jan', '5 Jan', '6 Jan', '7 Jan', '8 Jan', '9 Jan', '10 Jan',
                '11 Jan', '12 Jan', '13 Jan', '14 Jan', '15 Jan', '16 Jan', '17 Jan', '18 Jan', '19 Jan', '20 Jan',
                '21 Jan', '22 Jan', '23 Jan', '24 Jan', '25 Jan', '26 Jan', '27 Jan', '28 Jan', '29 Jan', '30 Jan'
            ],
            datasets: [{
                label: 'AED',
                data: ['30000', '50000', '80000', '20000', '20000', '10000', '20000', '18000', '11000', '29000',
                    '11000', '23000', '10000', '90000', '29000', '35000', '3000', '30000', '50000', '80000',
                    '20000', '20000', '10000', '20000', '18000', '11000', '29000', '11000', '23000',
                    '10000', '90000', '29000', '35000', '3000'
                ],

                //   pointStyle: 'circle',
                //   pointRadius: 10,
                //   pointHoverRadius: 15,

                backgroundColor: [
                    '#0d6efd',
                    '#0dcaf0',
                    '#2ecc71',
                    '#dc3545',
                ]
            }]
        };
        const currentMonthIncomFromBookingsConfig = {
            type: 'line',
            data: currentMonthIncomFromBookingsData,
            options: {
                responsive: true,
                plugins: {
                    title: {
                        display: true,
                        text: (currentMonthIncomFromBookingsCTX) =>
                            'Current Month Total Income From Bookings Is 1,110,500,00  AED',
                    }
                }
            }
        };

        new Chart(currentMonthIncomFromBookingsCTX, currentMonthIncomFromBookingsConfig);

        // currentMonthIncomFromProducts




        // currentMonthOrders
        let currentMonthOrdersCTX = document.getElementById("ordersChart");

        const currentMonthOrdersData = {
            labels: ['1 Jan', '2 Jan', '3 Jan', '4 Jan', '5 Jan', '6 Jan', '7 Jan', '8 Jan', '9 Jan', '10 Jan',
                '11 Jan', '12 Jan', '13 Jan', '14 Jan', '15 Jan', '16 Jan', '17 Jan', '18 Jan', '19 Jan', '20 Jan',
                '21 Jan', '22 Jan', '23 Jan', '24 Jan', '25 Jan', '26 Jan', '27 Jan', '28 Jan', '29 Jan', '30 Jan'
            ],
            datasets: [{
                label: 'Orders',
                data: ['200', '400', '600', '100', '600', '500', '900', '100', '400', '300', '800', '900',
                    '1000', '1200', '2000', '300', '2200', '200', '400', '600', '100', '600', '500', '900',
                    '100', '400', '300', '800', '900', '1000', '1200', '2000', '300', '2200'
                ],

                pointStyle: 'circle',
                pointRadius: 10,
                pointHoverRadius: 15
            }]
        };
        const currentMonthOrdersConfig = {
            type: 'bar',
            data: currentMonthOrdersData,
            options: {
                responsive: true,
                plugins: {
                    title: {
                        display: true,
                        text: (ctx) => 'Current Month  Total Orders Is 2,510,00 ',
                    }
                }
            }
        };

        new Chart(currentMonthOrdersCTX, currentMonthOrdersConfig);

        // currentMonthOrders
        // product chart

        let ctx3 = document.getElementById("productsChart");

        const data3 = {
            labels: ['In Stock', 'Out Of Stock', ],
            datasets: [{
                label: 'Products',
                data: ['1800', '1200'],

                pointStyle: 'circle',
                pointRadius: 10,
                pointHoverRadius: 15
            }]
        };
        const config3 = {
            type: 'pie',
            data: data3,
            options: {
                responsive: true,
                plugins: {
                    title: {
                        display: true,
                        text: (ctx) => 'Total Products Is 3,000,00 Product ',
                    }
                }
            }

        };
        new Chart(ctx3, config3);
        // product chart

        // ordersStatusChart


        let ctx4 = document.getElementById("ordersStatusChart");

        const data4 = {
            labels: ['New', 'Inprogress', 'Delivered', 'Cancelled'],
            datasets: [{
                label: 'Order',
                data: ['999', '992', '5000', '99'],

                pointStyle: 'circle',
                pointRadius: 10,
                pointHoverRadius: 15,
                backgroundColor: [
                    '#0d6efd',
                    '#0dcaf0',
                    '#2ecc71',
                    '#dc3545',
                ]

            }]
        };
        const config4 = {
            type: 'pie',
            data: data4,
            options: {
                responsive: true,
                plugins: {
                    title: {
                        display: true,
                        text: (ctx) => 'Total Orders Is 3,000,00 Order ',
                    },

                }
            }

        };
        new Chart(ctx4, config4);

        // ordersStatusChart
    </script>
@endsection
